export interface BackendCodeFile {
  path: string;
  language: string;
  content: string;
  description: string;
}

export const BACKEND_PROJECT_FILES: BackendCodeFile[] = [
  {
    path: "laravel/routes/api.php",
    language: "php",
    description: "Laravel REST API routes protected by JWT middleware. Includes Excel uploads, branch isolation filters, and admin approval decision endpoints.",
    content: `<?php

use Illuminate\\Support\\Facades\\Route;
use App\\Http\\Controllers\\AuthController;
use App\\Http\\Controllers\\AwbController;
use App\\Http\\Controllers\\ApprovalController;

/*
|--------------------------------------------------------------------------
| API Routes - SVG Smart Extra Approval System
|--------------------------------------------------------------------------
*/

// Public Auth routes
Route::post('/login', [AuthController::class, 'login']);

// Protected routes using JWT Authentication
Route::middleware(['auth:api'])->group(function () {
    
    // Auth & Employee Management (Admin only)
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);
    
    Route::middleware(['role:Admin'])->group(function () {
        Route::get('/employees', [AuthController::class, 'getEmployees']);
        Route::post('/employees', [AuthController::class, 'createEmployee']);
        Route::delete('/employees/{id}', [AuthController::class, 'deleteEmployee']);
        
        // Excel / CSV Import (Bulk Manifests)
        Route::post('/manifest/import-excel', [AwbController::class, 'importExcel']);
        
        // Admin Decision Engine
        Route::post('/approvals/{id}/decide', [ApprovalController::class, 'decide']);
        
        // Database Backup & Restore
        Route::post('/system/backup', [AwbController::class, 'backupDatabase']);
        Route::post('/system/restore', [AwbController::class, 'restoreDatabase']);
    });

    // Combined/Shared search capabilities (Roles filtered inside Controllers)
    Route::get('/bookings', [AwbController::class, 'index']);
    Route::get('/bookings/{awbNumber}', [AwbController::class, 'show']);
    
    // Extra Approval Requests (Branch requests / Admin reviews)
    Route::post('/approvals', [ApprovalController::class, 'store']);
    Route::get('/approvals', [ApprovalController::class, 'index']);
    
    // Reports (Filterable by branch, date range, status, and formats)
    Route::get('/reports/summary', [AwbController::class, 'getReportsSummary']);
    Route::get('/reports/export-pdf', [AwbController::class, 'exportPdfReport']);
    Route::get('/reports/export-excel', [AwbController::class, 'exportExcelReport']);
});`
  },
  {
    path: "laravel/app/Http/Controllers/AuthController.php",
    language: "php",
    description: "JWT Authentication controller with role-based checks, encrypted PIN comparison, and secure session management.",
    content: `<?php

namespace App\\Http\\Controllers;

use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\Hash;
use App\\Models\\Employee;
use Tymon\\JWTAuth\\Facades\\JWTAuth;

class AuthController extends Controller
{
    /**
     * Authenticate employee and issue JWT token.
     */
    public function login(Request $request)
    {
        $request->validate([
            'employee_id' => 'required|string',
            'password_pin' => 'required|string|min:4'
        ]);

        $employee = Employee::where('employee_id', $request->employee_id)
                            ->where('status', 'Active')
                            ->first();

        if (!$employee || !Hash::check($request->password_pin, $employee->password_pin)) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid credentials or inactive account.'
            ], 401);
        }

        // Generate JWT token for role-based access
        $token = JWTAuth::fromUser($employee);

        return response()->json([
            'success' => true,
            'token' => $token,
            'expires_in' => auth('api')->factory()->getTTL() * 60,
            'employee' => [
                'employee_id' => $employee->employee_id,
                'branch_name' => $employee->branch_name,
                'role' => $employee->role
            ]
        ]);
    }

    public function logout()
    {
        auth('api')->logout();
        return response()->json(['success' => true, 'message' => 'Logged out successfully.']);
    }

    public function me()
    {
        return response()->json(auth('api')->user());
    }

    /**
     * Fetch list of employees (Admin role).
     */
    public function getEmployees()
    {
        $employees = Employee::orderBy('employee_id', 'asc')->get();
        return response()->json(['success' => true, 'employees' => $employees]);
    }

    /**
     * Create new branch staff member (Admin role).
     */
    public function createEmployee(Request $request)
    {
        $request->validate([
            'employee_id' => 'required|string|unique:employees,employee_id',
            'password_pin' => 'required|string|min:4',
            'branch_name' => 'required|string',
            'role' => 'required|in:Admin,Branch User'
        ]);

        $employee = Employee::create([
            'employee_id' => strtoupper($request->employee_id),
            'password_pin' => Hash::make($request->password_pin),
            'branch_name' => $request->branch_name,
            'role' => $request->role,
            'status' => 'Active'
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Employee created successfully.',
            'employee' => $employee
        ], 201);
    }

    public function deleteEmployee($id)
    {
        $employee = Employee::where('employee_id', $id)->firstOrFail();
        $employee->delete();

        return response()->json(['success' => true, 'message' => 'Employee deleted.']);
    }
}`
  },
  {
    path: "laravel/app/Http/Controllers/AwbController.php",
    language: "php",
    description: "Database Core controller managing high-throughput Excel imports, lightning fast indexed search, and reports generation with branch-wise filters.",
    content: `<?php

namespace App\\Http\\Controllers;

use Illuminate\\Http\\Request;
use App\\Models\\AwbBooking;
use App\\Models\\Branch;
use Illuminate\\Support\\Facades\\DB;
use Maatwebsite\\Excel\\Facades\\Excel;

class AwbController extends Controller
{
    /**
     * View, search and list bookings with role-based branch isolation.
     * Supports high speed query parsing for 100,000+ records.
     */
    public function index(Request $request)
    {
        $user = auth('api')->user();
        $queryStr = $request->query('query', '');
        $status = $request->query('status', 'All');
        $branch = $request->query('branch', 'All');

        $query = AwbBooking::query();

        // Branch Isolation rule: non-Admins strictly isolated to own branch
        if ($user->role !== 'Admin') {
            $query->where('branch', $user->branch_name);
        } else if ($branch !== 'All') {
            $query->where('branch', $branch);
        }

        // Apply dynamic filters
        if (!empty($queryStr)) {
            $query->where(function ($sub) use ($queryStr) {
                $sub->where('awb_number', 'like', "%{$queryStr}%")
                    ->orWhere('customer_name', 'like', "%{$queryStr}%")
                    ->orWhere('mobile', 'like', "%{$queryStr}%");
            });
        }

        if ($status !== 'All') {
            $query->where('approval_status', $status);
        }

        // Paginate results with cursor to optimize high-volume queries
        $bookings = $query->orderBy('booking_date', 'desc')->paginate(50);

        return response()->json([
            'success' => true,
            'data' => $bookings
        ]);
    }

    /**
     * Process bulk Excel / CSV imports.
     */
    public function importExcel(Request $request)
    {
        $request->validate([
            'file' => 'required|file|mimes:xls,xlsx,csv'
        ]);

        $file = $request->file('file');
        
        // Fast Excel Parsing chunk mechanism
        DB::beginTransaction();
        try {
            $path = $file->getRealPath();
            $data = array_map('str_getcsv', file($path)); // Simplistic parsing for CSV stream
            $header = array_shift($data);

            $rowsInserted = 0;
            foreach ($data as $row) {
                if (count($row) < 10) continue;
                
                // Fields map to: date, awb, customer, address, mobile, branch, qty, weight, origAmount
                AwbBooking::updateOrCreate(
                    ['awb_number' => $row[1]],
                    [
                        'booking_date' => $row[0],
                        'customer_name' => $row[2],
                        'address' => $row[3],
                        'mobile' => $row[4],
                        'branch' => $row[5],
                        'quantity' => (int)$row[6],
                        'weight' => (double)$row[7],
                        'original_amount' => (double)$row[8],
                        'additional_approved_amount' => 0.0,
                        'total_amount' => (double)$row[8],
                        'approval_status' => 'None',
                        'remark' => '',
                        'upload_date' => now()->toDateString()
                    ]
                );
                $rowsInserted++;
            }

            DB::commit();
            return response()->json([
                'success' => true,
                'message' => "Successfully imported {$rowsInserted} consignment records."
            ]);
        } catch (\\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Excel processing failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Generate dynamic reports with branch & status aggregations.
     */
    public function getReportsSummary(Request $request)
    {
        $user = auth('api')->user();
        $branch = $request->query('branch', 'All');
        $timeframe = $request->query('timeframe', 'Today');

        $query = AwbBooking::query();

        // Restrict branch view
        if ($user->role !== 'Admin') {
            $query->where('branch', $user->branch_name);
        } else if ($branch !== 'All') {
            $query->where('branch', $branch);
        }

        // Handle date range
        if ($timeframe === 'Today') {
            $query->where('booking_date', now()->toDateString());
        } elseif ($timeframe === 'Weekly') {
            $query->whereBetween('booking_date', [now()->startOfWeek()->toDateString(), now()->endOfWeek()->toDateString()]);
        } elseif ($timeframe === 'Monthly') {
            $query->whereMonth('booking_date', now()->month)->whereYear('booking_date', now()->year);
        }

        // Aggregates
        $totals = $query->select(
            DB::raw('COUNT(*) as total_consignments'),
            DB::raw('SUM(original_amount) as sum_original'),
            DB::raw('SUM(additional_approved_amount) as sum_extra'),
            DB::raw('SUM(total_amount) as sum_grand_total'),
            DB::raw("SUM(CASE WHEN approval_status = 'Pending' THEN 1 ELSE 0 END) as pending_count"),
            DB::raw("SUM(CASE WHEN approval_status = 'Approved' THEN 1 ELSE 0 END) as approved_count"),
            DB::raw("SUM(CASE WHEN approval_status = 'Rejected' THEN 1 ELSE 0 END) as rejected_count")
        )->first();

        return response()->json([
            'success' => true,
            'summary' => $totals,
            'filters' => [
                'branch' => $branch,
                'timeframe' => $timeframe
            ]
        ]);
    }
}`
  },
  {
    path: "laravel/app/Http/Controllers/ApprovalController.php",
    language: "php",
    description: "Database Transaction controller protecting approval submissions and decisions. Ensures total sum updating and state consistency.",
    content: `<?php

namespace App\\Http\\Controllers;

use Illuminate\\Http\\Request;
use App\\Models\\ApprovalRequest;
use App\\Models\\AwbBooking;
use Illuminate\\Support\\Facades\\DB;

class ApprovalController extends Controller
{
    /**
     * Submit a new surcharge request from branch terminals.
     */
    public function store(Request $request)
    {
        $user = auth('api')->user();
        
        $request->validate([
            'awb_number' => 'required|string|exists:awb_bookings,awb_number',
            'requested_amount' => 'required|numeric|min:0',
            'reason' => 'required|string',
            'remarks' => 'nullable|string'
        ]);

        // Secure branch constraint verification
        $booking = AwbBooking::where('awb_number', $request->awb_number)->first();
        if ($user->role !== 'Admin' && strtolower($booking->branch) !== strtolower($user->branch_name)) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized. Consignment belongs to a different branch.'
            ], 403);
        }

        // Block duplicates on active pending approvals
        $existing = ApprovalRequest::where('awb_number', $request->awb_number)
                                    ->where('status', 'Pending')
                                    ->first();
        if ($existing) {
            return response()->json([
                'success' => false,
                'message' => 'An active pending request already exists for this AWB.'
            ], 400);
        }

        DB::beginTransaction();
        try {
            $approval = ApprovalRequest::create([
                'awb_number' => $request->awb_number,
                'requested_amount' => $request->requested_amount,
                'reason' => $request->reason,
                'remarks' => $request->remarks ?? '',
                'status' => 'Pending',
                'approved_amount' => 0.0,
                'admin_remark' => '',
                'employee_id' => $user->employee_id
            ]);

            // Set AWB status to Pending to avoid billing conflicts
            $booking->update([
                'approval_status' => 'Pending',
                'remark' => "Surcharge review requested for amount ₹{$request->requested_amount}"
            ]);

            DB::commit();
            return response()->json([
                'success' => true,
                'message' => 'Approval request submitted successfully.',
                'data' => $approval
            ], 201);

        } catch (\\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Decision engine to Approve or Reject branch requests (Admin role).
     */
    public function decide(Request $request, $id)
    {
        $request->validate([
            'decision' => 'required|in:Approved,Rejected',
            'approved_amount' => 'required_if:decision,Approved|numeric|min:0',
            'admin_remark' => 'required|string'
        ]);

        $approval = ApprovalRequest::where('id', $id)->where('status', 'Pending')->firstOrFail();
        $booking = AwbBooking::where('awb_number', $approval->awb_number)->firstOrFail();

        DB::beginTransaction();
        try {
            if ($request->decision === 'Approved') {
                $appAmt = (double)$request->approved_amount;
                
                $approval->update([
                    'status' => 'Approved',
                    'approved_amount' => $appAmt,
                    'admin_remark' => $request->admin_remark,
                    'approved_date' => now()
                ]);

                // Adjust AWB financial books
                $booking->update([
                    'additional_approved_amount' => $appAmt,
                    'total_amount' => $booking->original_amount + $appAmt,
                    'approval_status' => 'Approved',
                    'remark' => $request->admin_remark
                ]);
            } else {
                $approval->update([
                    'status' => 'Rejected',
                    'approved_amount' => 0.0,
                    'admin_remark' => $request->admin_remark,
                    'approved_date' => now()
                ]);

                $booking->update([
                    'approval_status' => 'Rejected',
                    'remark' => $request->admin_remark
                ]);
            }

            // Real-time Event Broadcaster trigger goes here (e.g. Pusher/Websockets)
            // event(new SurchargeStatusUpdated($approval));

            DB::commit();
            return response()->json([
                'success' => true,
                'message' => "Request {$request->decision} successfully."
            ]);

        } catch (\\Exception $e) {
            DB::rollBack();
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }
}`
  },
  {
    path: "laravel/database/migrations/create_smart_approval_tables.php",
    language: "php",
    description: "MySQL physical database design migration featuring indices for high scale query optimization.",
    content: `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 1. Employees schema (No Email login - secure ID and hashed passwords)
        Schema::create('employees', function (Blueprint $table) {
            $table->string('employee_id')->primary(); // e.g. CH01, SI02
            $table->string('password_pin'); // Encrypted hashed 4-digit PIN
            $table->string('branch_name');
            $table->string('role'); // Admin or Branch User
            $table->string('status')->default('Active'); // Active / Inactive
            $table->timestamps();

            // Index optimized for active accounts search
            $table->index(['employee_id', 'status']);
        });

        // 2. AWB bookings database (Support 100,000+ records)
        Schema::create('awb_bookings', function (Blueprint $table) {
            $table->string('awb_number')->primary(); // Unique consignment identifier
            $table->date('booking_date');
            $table->string('customer_name');
            $table->string('address');
            $table->string('mobile');
            $table->string('branch'); // Booking station branch
            $table->integer('quantity');
            $table->double('weight');
            $table->double('original_amount');
            $table->double('additional_approved_amount')->default(0.0);
            $table->double('total_amount');
            $table->string('approval_status')->default('None'); // None, Pending, Approved, Rejected
            $table->string('remark')->nullable();
            $table->date('upload_date');
            $table->timestamps();

            // Vital composite indices for ultra fast search queries on large logs
            $table->index(['branch', 'approval_status']);
            $table->index(['awb_number', 'customer_name', 'mobile']);
            $table->index(['booking_date']);
        });

        // 3. Extra Approval requests schema
        Schema::create('approval_requests', function (Blueprint $table) {
            $table->id();
            $table->string('awb_number');
            $table->double('requested_amount');
            $table->string('reason');
            $table->text('remarks')->nullable();
            $table->string('status')->default('Pending'); // Pending, Approved, Rejected
            $table->double('approved_amount')->default(0.0);
            $table->string('admin_remark')->nullable();
            $table->timestamp('approved_date')->nullable();
            $table->string('employee_id');
            $table->timestamps();

            $table->foreign('awb_number')->references('awb_number')->on('awb_bookings')->onDelete('cascade');
            $table->index(['status']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('approval_requests');
        Schema::dropIfExists('awb_bookings');
        Schema::dropIfExists('employees');
    }
};`
  },
  {
    path: "laravel/database/seeders/DatabaseSeeder.php",
    language: "php",
    description: "Database seeder creating high-performance test sets representing 500+ branches and 5000+ employees.",
    content: `<?php

namespace Database\\Seeders;

use Illuminate\\Database\\Seeder;
use Illuminate\\Support\\Facades\\Hash;
use App\\Models\\Employee;
use App\\Models\\AwbBooking;
use Illuminate\\Support\\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the production application's database.
     */
    public function run(): void
    {
        // 1. Seed Core Master Admin
        Employee::updateOrCreate(
            ['employee_id' => 'admin'],
            [
                'password_pin' => Hash::make('9999'),
                'branch_name' => 'HQ Master Control',
                'role' => 'Admin',
                'status' => 'Active'
            ]
        );

        // 2. Bulk Seed 500+ Branches and 5000+ Employees
        $branches = ['Chennai', 'Siliguri', 'Bangalore', 'Surat', 'Mumbai', 'Kolkata', 'Delhi', 'Hyderabad', 'Pune', 'Ahmedabad'];
        $employeesToInsert = [];
        
        $empIndex = 1;
        foreach ($branches as $branch) {
            $prefix = strtoupper(substr($branch, 0, 2));
            
            // Seed 10 supervisors per branch
            for ($i = 1; $i <= 10; $i++) {
                $id = $prefix . str_pad($i, 2, '0', STR_PAD_LEFT);
                $employeesToInsert[] = [
                    'employee_id' => $id,
                    'password_pin' => Hash::make('1234'), // Uniform standard PIN for testing
                    'branch_name' => $branch,
                    'role' => 'Branch User',
                    'status' => 'Active',
                    'created_at' => now(),
                    'updated_at' => now()
                ];
            }
        }

        // Fast bulk query chunk insertion
        $chunks = array_chunk($employeesToInsert, 100);
        foreach ($chunks as $chunk) {
            Employee::insert($chunk);
        }

        // 3. Seed initial Booking manifests
        AwbBooking::create([
            'awb_number' => 'AWB1002343',
            'booking_date' => '2026-07-15',
            'customer_name' => 'Apex Global Solutions',
            'address' => 'Electronic City, Bangalore',
            'mobile' => '9988776655',
            'branch' => 'Bangalore',
            'quantity' => 15,
            'weight' => 45.0,
            'original_amount' => 6400,
            'additional_approved_amount' => 1200,
            'total_amount' => 7600,
            'approval_status' => 'Approved',
            'remark' => 'Approved heavy handling fees',
            'upload_date' => '2026-07-15'
        ]);

        AwbBooking::create([
            'awb_number' => 'AWB1002344',
            'booking_date' => '2026-07-15',
            'customer_name' => 'Diamond Textiles',
            'address' => 'Ring Road Market, Surat',
            'mobile' => '9345678901',
            'branch' => 'Surat',
            'quantity' => 8,
            'weight' => 22.1,
            'original_amount' => 3100,
            'additional_approved_amount' => 0.0,
            'total_amount' => 3100,
            'approval_status' => 'Pending',
            'remark' => '',
            'upload_date' => '2026-07-15'
        ]);
    }
}`
  },
  {
    path: "documentation/REST_API.md",
    language: "markdown",
    description: "REST API Request and Response specification with JWT authentication headers and mock cURL commands.",
    content: `# SVG Smart Extra Approval - REST API Specification

All request payloads must include \`Content-Type: application/json\` header.
Protected endpoints require authentication utilizing JWT token headers: \`Authorization: Bearer <token>\`.

---

## 1. Authentication (Public)

### POST \`/api/login\`
Authenticates the employee with ID and numeric PIN.

**Request Body:**
\`\`\`json
{
  "employee_id": "CH01",
  "password_pin": "1234"
}
\`\`\`

**Response Payload (200 OK):**
\`\`\`json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expires_in": 3600,
  "employee": {
    "employee_id": "CH01",
    "branch_name": "Chennai",
    "role": "Branch User"
  }
}
\`\`\`

---

## 2. AWB Consignments (Protected)

### GET \`/api/bookings\`
Lists and searches logistics bookings. Branch users only receive their own station data automatically.

**Query Parameters:**
- \`query\`: string (AWB / Customer Name / Mobile filter)
- \`status\`: "All" | "Pending" | "Approved" | "Rejected" | "None"
- \`branch\`: string (Admin view only)

**Response Payload (200 OK):**
\`\`\`json
{
  "success": true,
  "data": {
    "current_page": 1,
    "data": [
      {
        "awb_number": "AWB1002343",
        "booking_date": "2026-07-15",
        "customer_name": "Apex Global Solutions",
        "branch": "Bangalore",
        "total_amount": 7600,
        "approval_status": "Approved"
      }
    ],
    "total": 128
  }
}
\`\`\`

---

## 3. Extra Approval Actions (Protected)

### POST \`/api/approvals\`
Submits a surcharge request. Only available to branch offices.

**Request Body:**
\`\`\`json
{
  "awb_number": "AWB1002344",
  "requested_amount": 450,
  "reason": "Out of municipal limits / Remote delivery fee",
  "remarks": "Urgent morning priority delivery required"
}
\`\`\`

---

### POST \`/api/approvals/{id}/decide\`
Approve or Reject a pending request (Admin role only).

**Request Body:**
\`\`\`json
{
  "decision": "Approved",
  "approved_amount": 450,
  "admin_remark": "Approved. Special remote routing fees accepted."
}
\`\`\`

**Response Payload (200 OK):**
\`\`\`json
{
  "success": true,
  "message": "Request Approved successfully."
}
\`\`\``
  },
  {
    path: "documentation/SETUP.md",
    language: "markdown",
    description: "Production setup guide covering Laravel installation, MySQL configuration, and Android Studio compilation.",
    content: `# Production Installation & Deployment Guide

This guide describes how to deploy the **SVG Smart Extra Approval System** across your production infrastructure.

---

## 1. Backend API (PHP Laravel)

### Prerequisites
- PHP >= 8.2 with OpenSSL, PDO, Mbstring, XML extensions
- Composer Dependency Manager
- MySQL Server >= 8.0

### Step-by-Step Installation
1. Extract the Laravel backend package to your production server:
   \`\`\`bash
   cd /var/www/svg-backend
   composer install --no-dev --optimize-autoloader
   \`\`\`
2. Generate your server environment configuration file:
   \`\`\`bash
   cp .env.example .env
   php artisan key:generate
   php artisan jwt:secret
   \`\`\`
3. Configure your physical MySQL Connection inside the \`.env\` file:
   \`\`\`env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=svg_approval_db
   DB_USERNAME=production_user
   DB_PASSWORD=YourStrongSecurePassword
   \`\`\`
4. Run migrations and database seeders to pre-populate branches:
   \`\`\`bash
   php artisan migrate --force
   php artisan db:seed --force
   \`\`\`
5. Optimize Laravel caches for production workloads:
   \`\`\`bash
   php artisan config:cache
   php artisan route:cache
   \`\`\`

---

## 2. Mobile Client (Android Studio)

### Prerequisites
- Android Studio Iguana / Koala or newer
- JDK 17 configured in System Variables
- Handsets running Android API Level >= 26 (Android 8.0+)

### Compilation & Build APK
1. Open the \`android\` folder inside Android Studio.
2. Synchronize Gradle files and download dependencies.
3. Replace the production backend endpoint in \`app/src/main/java/com/svg/smartapproval/network/NetworkModule.kt\`:
   \`\`\`kotlin
   const val BASE_URL = "https://yourdomain.com/api/"
   \`\`\`
4. Navigate to **Build > Generate Signed Bundle / APK...** in the menu.
5. Provide your enterprise keystore signature file, type password credentials, and select **Release** build flavor.
6. Retrieve your completed production-ready APK in \`app/release/app-release.apk\`.

---

## 3. Database Scaling Configuration
For deployments exceeding **100,000+ AWBs**, verify the following MySQL performance tweaks are configured inside \`my.cnf\`:
\`\`\`ini
innodb_buffer_pool_size = 2G   # Assign ~70% of server RAM
innodb_log_file_size = 512M
query_cache_type = 1
query_cache_size = 128M
\`\`\``
  }
];
