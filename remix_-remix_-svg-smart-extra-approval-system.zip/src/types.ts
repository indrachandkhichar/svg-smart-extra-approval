export interface Employee {
  employeeId: string;
  passwordPin: string; // 4 digit PIN
  branchName: string;
  status: "Active" | "Inactive";
  role: "Admin" | "Branch User";
  permissions?: string[]; // permissions list e.g. "Create User", "Approve Surcharges"
}

export interface AWB {
  branch: string;
  bookingDate: string; // YYYY-MM-DD
  awbNumber: string;
  customerName: string;
  customerAddress: string;
  deliveryBranch: string;
  odaOrLocal: "ODA" | "Local";
  boxQuantity: number;
  weight: number; // kg
  actualAmount: number;
  additionalAmount: number;
  totalAmount: number; // actualAmount + additionalAmount
  approvalStatus: "Pending" | "Approved" | "Rejected" | "None";
  adminRemark: string;
  uploadDate: string;
}

export interface ExtraApprovalRequest {
  id: string;
  awbNumber: string;
  requestedAmount: number;
  reason: string;
  remarks: string;
  status: "Pending" | "Approved" | "Rejected";
  approvedAmount: number;
  adminRemark: string;
  approvedDate: string;
  employeeId: string;
}

export interface SyncLog {
  id: string;
  timestamp: string;
  type: "Upload" | "Approval" | "Request" | "Sync" | "Backup" | "Restore" | "UserManagement";
  message: string;
  sender: string;
  status?: "success" | "warning" | "error" | "info";
}

export interface KotlinFile {
  name: string;
  category: "Room" | "Compose UI" | "ViewModel" | "Repository" | "Config";
  content: string;
  description: string;
}
