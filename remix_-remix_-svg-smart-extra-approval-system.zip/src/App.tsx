import React, { useState, useEffect, useRef, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldAlert,
  Download,
  Upload,
  Search,
  Filter,
  Plus,
  Trash2,
  FileSpreadsheet,
  FileDown,
  RefreshCw,
  Sliders,
  LogOut,
  UserCheck,
  Check,
  X,
  PlusCircle,
  TrendingUp,
  AlertCircle,
  HelpCircle,
  Wifi,
  Database,
  Smartphone,
  CheckCircle,
  XCircle,
  Coins,
  MapPin,
  Calendar,
  Lock,
  Phone,
  BarChart3,
  Copy,
  Folder,
  FileCode,
  Info,
  Layers,
  ChevronRight,
  Sparkles,
  Settings,
  ArrowRightLeft,
  Sun,
  Moon,
  Camera,
  QrCode
} from "lucide-react";
import { Employee, AWB, ExtraApprovalRequest, SyncLog } from "./types";
import { ANDROID_PROJECT_FILES, AndroidCodeFile } from "./kotlinCode";
import { BACKEND_PROJECT_FILES, BackendCodeFile } from "./backendCode";
import * as XLSX from "xlsx";
import { jsPDF } from "jspdf";
import QRCode from "qrcode";

// Import Custom Modular Components
import { downloadSampleExcel } from "./components/SampleExcelTemplate";
import { DashboardCharts } from "./components/DashboardCharts";
import { Splash } from "./components/Splash";
import { UserManagement } from "./components/UserManagement";
import { calculateReportSummary, generatePDFReport, generateExcelReport } from "./components/ReportEngine";
import { QRScanner } from "./components/QRScanner";

// Initial realistic preloaded branch employees
const INITIAL_EMPLOYEES: Employee[] = [
  { employeeId: "CH01", passwordPin: "1234", branchName: "Chennai", status: "Active", role: "Branch User", permissions: ["Export Reports", "Import Excel"] },
  { employeeId: "SI02", passwordPin: "5678", branchName: "Siliguri", status: "Active", role: "Branch User", permissions: ["Export Reports"] },
  { employeeId: "RT01", passwordPin: "1111", branchName: "Rohtak", status: "Active", role: "Branch User", permissions: ["Export Reports"] },
  { employeeId: "KO01", passwordPin: "2222", branchName: "Kolkata", status: "Active", role: "Branch User", permissions: ["Export Reports"] },
];

// Initial preloaded booking data representing courier AWB bookings
const INITIAL_AWB_BOOKINGS: AWB[] = [
  { bookingDate: "2026-07-15", awbNumber: "AWB1002341", customerName: "Acme Industrial Tools", customerAddress: "Sector 4, Industrial Area, Chennai", deliveryBranch: "Siliguri", odaOrLocal: "Local", boxQuantity: 5, weight: 12.5, actualAmount: 1850, additionalAmount: 0, totalAmount: 1850, approvalStatus: "None", adminRemark: "", branch: "Chennai", uploadDate: "2026-07-15" },
  { bookingDate: "2026-07-15", awbNumber: "AWB1002342", customerName: "Bharat Electronics", customerAddress: "Hill Cart Road, Siliguri", deliveryBranch: "Chennai", odaOrLocal: "Local", boxQuantity: 2, weight: 4.8, actualAmount: 750, additionalAmount: 0, totalAmount: 750, approvalStatus: "None", adminRemark: "", branch: "Siliguri", uploadDate: "2026-07-15" },
  { bookingDate: "2026-07-15", awbNumber: "AWB1002343", customerName: "Apex Global Solutions", customerAddress: "Electronic City, Bangalore", deliveryBranch: "Chennai", odaOrLocal: "ODA", boxQuantity: 15, weight: 45.0, actualAmount: 6400, additionalAmount: 1200, totalAmount: 7600, approvalStatus: "Approved", adminRemark: "Heavy machinery handling surcharges", branch: "Chennai", uploadDate: "2026-07-15" },
  { bookingDate: "2026-07-15", awbNumber: "AWB1002344", customerName: "Diamond Textiles", customerAddress: "Ring Road Market, Surat", deliveryBranch: "Rohtak", odaOrLocal: "ODA", boxQuantity: 8, weight: 22.1, actualAmount: 3100, additionalAmount: 450, totalAmount: 3550, approvalStatus: "Pending", adminRemark: "", branch: "Rohtak", uploadDate: "2026-07-15" },
  { bookingDate: "2026-07-16", awbNumber: "AWB1002345", customerName: "Venkateswara Garments", customerAddress: "Mylapore High Street, Chennai", deliveryBranch: "Kolkata", odaOrLocal: "Local", boxQuantity: 3, weight: 6.2, actualAmount: 950, additionalAmount: 200, totalAmount: 1150, approvalStatus: "Pending", adminRemark: "", branch: "Chennai", uploadDate: "2026-07-16" },
  { bookingDate: "2026-07-16", awbNumber: "AWB1002346", customerName: "Himalayan Tea Corp", customerAddress: "Sevoke Road Bypass, Siliguri", deliveryBranch: "Rohtak", odaOrLocal: "Local", boxQuantity: 12, weight: 35.5, actualAmount: 4800, additionalAmount: 0, totalAmount: 4800, approvalStatus: "None", adminRemark: "", branch: "Siliguri", uploadDate: "2026-07-16" },
  { bookingDate: "2026-07-16", awbNumber: "AWB1002347", customerName: "Nandi Rice Millers", customerAddress: "Whitefield Inner Ring Road, Bangalore", deliveryBranch: "Chennai", odaOrLocal: "ODA", boxQuantity: 20, weight: 100.0, actualAmount: 12500, additionalAmount: 0, totalAmount: 12500, approvalStatus: "Rejected", adminRemark: "Weight limit exceeded for current vehicle", branch: "Chennai", uploadDate: "2026-07-16" },
  { bookingDate: "2026-07-16", awbNumber: "AWB1002348", customerName: "Zari Silk Weavers", customerAddress: "Textile Market, Surat", deliveryBranch: "Siliguri", odaOrLocal: "Local", boxQuantity: 1, weight: 1.5, actualAmount: 450, additionalAmount: 0, totalAmount: 450, approvalStatus: "None", adminRemark: "", branch: "Siliguri", uploadDate: "2026-07-16" },
];

// Initial preloaded approval requests
const INITIAL_APPROVAL_REQUESTS: ExtraApprovalRequest[] = [
  { id: "req_1", awbNumber: "AWB1002343", requestedAmount: 1200, reason: "Forklift loader rental and wooden pallet crating required due to fragile heavy equipment", remarks: "Requested by Bangalore branch supervisor", status: "Approved", approvedAmount: 1200, adminRemark: "Approved heavy handling fees", approvedDate: "2026-07-15 16:30", employeeId: "BI01" },
  { id: "req_2", awbNumber: "AWB1002344", requestedAmount: 450, reason: "Special priority delivery zone charge outside municipal limits", remarks: "Requires urgent morning transit", status: "Pending", approvedAmount: 0, adminRemark: "", approvedDate: "", employeeId: "SU05" },
  { id: "req_3", awbNumber: "AWB1002345", requestedAmount: 200, reason: "Toll plaza surcharge and temporary storage holding fee", remarks: "Customer requested delivery delay", status: "Pending", approvedAmount: 0, adminRemark: "", approvedDate: "", employeeId: "CH01" },
  { id: "req_4", awbNumber: "AWB1002347", requestedAmount: 2500, reason: "Tailgate lift truck and extra loaders needed for 100kg cargo unloading", remarks: "Unloading point has no cargo bay", status: "Rejected", approvedAmount: 0, adminRemark: "Rejected. Surcharges must be billed to client at checkout time.", approvedDate: "2026-07-16 10:15", employeeId: "BI01" },
];

export default function App() {
  // Database States (Simulated Room SQLite)
  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem("svg_employees");
    return saved ? JSON.parse(saved) : INITIAL_EMPLOYEES;
  });

  const [awbBookings, setAwbBookings] = useState<AWB[]>(() => {
    const saved = localStorage.getItem("svg_bookings");
    return saved ? JSON.parse(saved) : INITIAL_AWB_BOOKINGS;
  });

  const [approvalRequests, setApprovalRequests] = useState<ExtraApprovalRequest[]>(() => {
    const saved = localStorage.getItem("svg_requests");
    return saved ? JSON.parse(saved) : INITIAL_APPROVAL_REQUESTS;
  });

  // Local sync session logs
  const [syncLogs, setSyncLogs] = useState<SyncLog[]>([
    { id: "1", timestamp: "08:15 AM", type: "Sync", message: "Database initialized with secure offline encryption.", sender: "System", status: "success" },
    { id: "2", timestamp: "08:30 AM", type: "Upload", message: "Imported 8 logistics manifest entries.", sender: "Admin Mobile", status: "success" },
  ]);

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem("svg_dark_mode");
    return saved !== null ? saved === "true" : true;
  });
  const [showSplash, setShowSplash] = useState(true);

  // UI Flow states
  const [activeTab, setActiveTab] = useState<"simulator" | "kotlin_hub" | "about">("simulator");
  const [deviceRole, setDeviceRole] = useState<"Admin" | "Branch">("Admin");
  
  // Login Session states
  const [adminLoggedIn, setAdminLoggedIn] = useState(false);
  const [adminPassword, setAdminPassword] = useState(() => {
    return localStorage.getItem("svg_admin_password") || "9999";
  });
  const [branchLoggedInUser, setBranchLoggedInUser] = useState<Employee | null>(null);
  
  // Login Forms
  const [adminLoginInput, setAdminLoginInput] = useState("");
  const [branchLoginId, setBranchLoginId] = useState("CH01");
  const [branchLoginPin, setBranchLoginPin] = useState("");
  const [loginError, setLoginError] = useState("");

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | "Pending" | "Approved" | "Rejected" | "None">("All");
  const [dateFilter, setDateFilter] = useState<"All" | "Today" | "Yesterday">("All");
  const [branchFilter, setBranchFilter] = useState<string>("All");
  const [selectedAwbNumbers, setSelectedAwbNumbers] = useState<Record<string, boolean>>({});

  // Extract all unique branches dynamically
  const allBranches = useMemo(() => {
    const list = Array.from(new Set(awbBookings.map((b) => b.branch))).filter(Boolean);
    return list.sort();
  }, [awbBookings]);

  // Admin and Branch state updates
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncSuccessMsg, setSyncSuccessMsg] = useState("");
  
  // Detail views and modals
  const [selectedAwb, setSelectedAwb] = useState<AWB | null>(null);
  const [showRequestExtraModal, setShowRequestExtraModal] = useState(false);
  const [requestExtraAmount, setRequestExtraAmount] = useState("");
  const [requestExtraReason, setRequestExtraReason] = useState("Toll Surcharge");
  const [requestExtraRemarks, setRequestExtraRemarks] = useState("");

  // Admin Approval Decision states
  const [showApprovalDialog, setShowApprovalDialog] = useState(false);
  const [selectedRequestToDecide, setSelectedRequestToDecide] = useState<ExtraApprovalRequest | null>(null);
  const [decisionType, setDecisionType] = useState<"Approve" | "Reject">("Approve");
  const [decisionApprovedAmount, setDecisionApprovedAmount] = useState("");
  const [decisionAdminRemark, setDecisionAdminRemark] = useState("");

  // Manage Employees states
  const [newEmpId, setNewEmpId] = useState("");
  const [newEmpBranch, setNewEmpBranch] = useState("");
  const [newEmpPin, setNewEmpPin] = useState("");
  const [newEmpError, setNewEmpError] = useState("");

  // Kotlin and Backend Code hub states
  const [codeHubPlatform, setCodeHubPlatform] = useState<"android" | "backend">("android");
  const [selectedKotlinFile, setSelectedKotlinFile] = useState<AndroidCodeFile>(ANDROID_PROJECT_FILES[2]);
  const [selectedBackendFile, setSelectedBackendFile] = useState<BackendCodeFile>(BACKEND_PROJECT_FILES[0]);

  // Export & Import states
  const [rawCsvPaste, setRawCsvPaste] = useState("");
  const [showImportArea, setShowImportArea] = useState(false);
  const [showSettingsPanel, setShowSettingsPanel] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // QR Scanner States
  const [showQRScanner, setShowQRScanner] = useState(false);
  const [selectedAwbQrUrl, setSelectedAwbQrUrl] = useState<string>("");

  // Effect to generate QR Code Data URL when selectedAwb changes
  useEffect(() => {
    if (selectedAwb) {
      QRCode.toDataURL(selectedAwb.awbNumber, {
        margin: 1,
        width: 140,
        color: {
          dark: "#0f172a", // deep navy
          light: "#ffffff", // clean white
        },
      })
        .then((url) => {
          setSelectedAwbQrUrl(url);
        })
        .catch((err) => {
          console.error("QR Code Generation failed:", err);
          setSelectedAwbQrUrl("");
        });
    } else {
      setSelectedAwbQrUrl("");
    }
  }, [selectedAwb]);

  // QR Scan Success Handler
  const handleQRScanSuccess = (awbNumber: string) => {
    const found = awbBookings.find(
      (awb) => awb.awbNumber.toLowerCase() === awbNumber.trim().toLowerCase()
    );
    if (found) {
      setSelectedAwb(found);
      setShowQRScanner(false);
      addLog(
        "Sync",
        `Scanned AWB Label QR [${found.awbNumber}] successfully. Loading details.`,
        deviceRole === "Admin" ? "Admin master" : branchLoggedInUser?.branchName || "Scan Module",
        "success"
      );
    } else {
      alert(`Scanned AWB code "${awbNumber}" but it was not found in the local database list.`);
    }
  };

  // Stats Counters
  const totalAmountBilled = useMemo(() => {
    return awbBookings.reduce((sum, item) => sum + item.actualAmount + item.additionalAmount, 0);
  }, [awbBookings]);

  const totalExtraApproved = useMemo(() => {
    return awbBookings.reduce((sum, item) => sum + item.additionalAmount, 0);
  }, [awbBookings]);

  // Save changes to local storage to simulate secure offline phone storage
  useEffect(() => {
    localStorage.setItem("svg_dark_mode", String(isDarkMode));
  }, [isDarkMode]);

  useEffect(() => {
    localStorage.setItem("svg_employees", JSON.stringify(employees));
  }, [employees]);

  useEffect(() => {
    localStorage.setItem("svg_bookings", JSON.stringify(awbBookings));
  }, [awbBookings]);

  useEffect(() => {
    localStorage.setItem("svg_requests", JSON.stringify(approvalRequests));
  }, [approvalRequests]);

  // Handler for secure admin login
  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminLoginInput === adminPassword) {
      setAdminLoggedIn(true);
      setLoginError("");
      addLog("Sync", "Admin authenticated securely on offline master device.", "Admin Mobile", "success");
    } else {
      setLoginError("Invalid Admin Master PIN! Hint: check code default '9999'");
      addLog("Sync", `Failed admin login attempt: Invalid PIN entered.`, "Admin Mobile", "error");
    }
  };

  // Handler for secure branch login
  const handleBranchLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = employees.find(
      (emp) => emp.employeeId.toUpperCase() === branchLoginId.toUpperCase() && emp.status === "Active"
    );
    if (user && user.passwordPin === branchLoginPin) {
      setBranchLoggedInUser(user);
      setLoginError("");
      addLog("Sync", `Employee ${user.employeeId} logged into branch desk.`, user.branchName, "success");
    } else {
      setLoginError("Invalid Employee ID or 4-digit PIN.");
      addLog("Sync", `Failed login attempt for Employee ID: ${branchLoginId}.`, "Branch Handset", "error");
    }
  };

  // Add event tracking log
  const addLog = (
    type: "Upload" | "Approval" | "Request" | "Sync" | "Backup" | "Restore" | "UserManagement",
    message: string,
    sender: string,
    status: "success" | "warning" | "error" | "info" = "success"
  ) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const newLog: SyncLog = {
      id: Math.random().toString(),
      timestamp: timeStr,
      type,
      message,
      sender,
      status
    };
    setSyncLogs((prev) => [newLog, ...prev.slice(0, 49)]);
  };

  // Submit new extra approval request (Branch Employee)
  const handleRequestExtraApproval = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAwb) return;
    const amountNum = parseFloat(requestExtraAmount);
    if (isNaN(amountNum) || amountNum <= 0) {
      alert("Please enter a valid requested amount!");
      return;
    }

    const newRequest: ExtraApprovalRequest = {
      id: "req_" + Math.random().toString(36).substr(2, 9),
      awbNumber: selectedAwb.awbNumber,
      requestedAmount: amountNum,
      reason: requestExtraReason,
      remarks: requestExtraRemarks,
      status: "Pending",
      approvedAmount: 0,
      adminRemark: "",
      approvedDate: "",
      employeeId: branchLoggedInUser?.employeeId || "System"
    };

    // Update approvals array
    setApprovalRequests((prev) => [newRequest, ...prev]);

    // Update local bookings state immediately
    setAwbBookings((prev) =>
      prev.map((awb) =>
        awb.awbNumber === selectedAwb.awbNumber
          ? { ...awb, approvalStatus: "Pending" }
          : awb
      )
    );

    // Update selected view
    setSelectedAwb((prev) => prev ? { ...prev, approvalStatus: "Pending" } : null);

    addLog("Request", `Requested extra ₹${amountNum} for ${selectedAwb.awbNumber}.`, branchLoggedInUser?.branchName || "Branch");
    setShowRequestExtraModal(false);
    setRequestExtraAmount("");
    setRequestExtraRemarks("");
    
    // Simulate real-time local network sync trigger
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncSuccessMsg("Sync completed! Sent offline request block to Admin.");
      setTimeout(() => setSyncSuccessMsg(""), 3000);
    }, 1200);
  };

  // Process Admin Decision (Approve or Reject extra billing request)
  const handleAdminDecisionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRequestToDecide) return;

    const approvedAmountNum = decisionType === "Approve" ? parseFloat(decisionApprovedAmount) : 0;
    if (decisionType === "Approve" && (isNaN(approvedAmountNum) || approvedAmountNum < 0)) {
      alert("Please specify a valid approved amount!");
      return;
    }

    const dateStr = new Date().toISOString().replace("T", " ").substring(0, 16);

    // Update requests array
    setApprovalRequests((prev) =>
      prev.map((req) =>
        req.id === selectedRequestToDecide.id
          ? {
              ...req,
              status: decisionType === "Approve" ? "Approved" : "Rejected",
              approvedAmount: approvedAmountNum,
              adminRemark: decisionAdminRemark,
              approvedDate: dateStr
            }
          : req
      )
    );

    // Update AWB master file
    setAwbBookings((prev) =>
      prev.map((awb) => {
        if (awb.awbNumber === selectedRequestToDecide.awbNumber) {
          const addAmt = decisionType === "Approve" ? approvedAmountNum : 0;
          return {
            ...awb,
            additionalApprovedAmount: addAmt,
            totalAmount: awb.originalAmount + addAmt,
            approvalStatus: decisionType === "Approve" ? "Approved" : "Rejected",
            remark: decisionAdminRemark
          };
        }
        return awb;
      })
    );

    addLog(
      "Approval",
      `${decisionType} ${selectedRequestToDecide.awbNumber}: extra ₹${approvedAmountNum}.`,
      "Admin master",
      decisionType === "Approve" ? "success" : "warning"
    );

    // If currently viewing the decided AWB, refresh it
    if (selectedAwb && selectedAwb.awbNumber === selectedRequestToDecide.awbNumber) {
      setSelectedAwb((prev) => {
        if (!prev) return null;
        const addAmt = decisionType === "Approve" ? approvedAmountNum : 0;
        return {
          ...prev,
          additionalApprovedAmount: addAmt,
          totalAmount: prev.originalAmount + addAmt,
          approvalStatus: decisionType === "Approve" ? "Approved" : "Rejected",
          remark: decisionAdminRemark
        };
      });
    }

    setShowApprovalDialog(false);
    setSelectedRequestToDecide(null);
    setDecisionApprovedAmount("");
    setDecisionAdminRemark("");
  };

  // Add a new branch employee securely
  const handleAddEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmpId.trim() || !newEmpBranch.trim() || !newEmpPin.trim()) {
      setNewEmpError("All fields are required!");
      return;
    }
    if (newEmpPin.length !== 4 || isNaN(parseInt(newEmpPin))) {
      setNewEmpError("PIN must be exactly a 4-digit number.");
      return;
    }
    if (employees.some((emp) => emp.employeeId.toUpperCase() === newEmpId.toUpperCase())) {
      setNewEmpError("Employee ID already exists!");
      return;
    }

    const newEmp: Employee = {
      employeeId: newEmpId.toUpperCase(),
      passwordPin: newEmpPin,
      branchName: newEmpBranch,
      status: "Active",
      role: "Branch User"
    };

    setEmployees((prev) => [...prev, newEmp]);
    setNewEmpId("");
    setNewEmpBranch("");
    setNewEmpPin("");
    setNewEmpError("");
    addLog("Sync", `Registered new branch employee ID ${newEmp.employeeId} for ${newEmp.branchName}.`, "Admin master");
  };

  // Toggle active/inactive status of employee
  const toggleEmployeeStatus = (id: string) => {
    setEmployees((prev) =>
      prev.map((emp) =>
        emp.employeeId === id
          ? { ...emp, status: emp.status === "Active" ? "Inactive" : "Active" }
          : emp
      )
    );
  };

  // Delete employee record
  const deleteEmployee = (id: string) => {
    if (confirm(`Are you sure you want to delete employee ${id}?`)) {
      setEmployees((prev) => prev.filter((emp) => emp.employeeId !== id));
      addLog("Sync", `Removed employee ID ${id} from database.`, "Admin Master", "warning");
    }
  };

  // Generate 1,000+ Records for high performance testing
  const generateLargeDatabase = () => {
    const branches = ["Chennai", "Siliguri", "Bangalore", "Surat"];
    const customers = [
      "Vasco Trans Logistics",
      "Global Apparel Sourcing",
      "Dynamic Spares & Components",
      "Royal Silk Exporters",
      "Precision Valves",
      "Inno Pack Pvt Ltd",
      "Matrix Hardware",
      "Sree Balaji Mills",
      "Kanchenjunga Organic Tea",
      "Deccan Parts Corp"
    ];

    const bulkAwbs: AWB[] = [];
    const baseAwbNum = 1003500;

    for (let i = 0; i < 1500; i++) {
      const branch = branches[Math.floor(Math.random() * branches.length)];
      const customer = customers[Math.floor(Math.random() * customers.length)];
      const qty = Math.floor(Math.random() * 25) + 1;
      const weight = Math.round((qty * (Math.random() * 5 + 1.2)) * 10) / 10;
      const originalAmt = Math.round(qty * 300 + weight * 25);
      
      const randomDaysAgo = Math.floor(Math.random() * 5);
      const bDateObj = new Date();
      bDateObj.setDate(bDateObj.getDate() - randomDaysAgo);
      const bDate = bDateObj.toISOString().split("T")[0];

      const randDelivery = branches[(Math.floor(Math.random() * branches.length) + 1) % branches.length];
      const isOda = Math.random() > 0.5 ? "ODA" : "Local";

      bulkAwbs.push({
        bookingDate: bDate,
        awbNumber: `AWB${baseAwbNum + i}`,
        customerName: `${customer} #${Math.floor(Math.random() * 900 + 100)}`,
        customerAddress: `${Math.floor(Math.random() * 120 + 5)} High Road Market Area, ${branch}`,
        deliveryBranch: randDelivery,
        odaOrLocal: isOda,
        boxQuantity: qty,
        weight,
        actualAmount: originalAmt,
        additionalAmount: 0,
        totalAmount: originalAmt,
        approvalStatus: "None",
        adminRemark: "",
        branch,
        uploadDate: "2026-07-16"
      });
    }

    setAwbBookings((prev) => [...prev, ...bulkAwbs]);
    addLog("Upload", `Generated 1,500 mock AWBs to stress-test local performance.`, "Admin Tool");
    alert("Injected 1,500 active logistics records! Scroll down and test instant queries.");
  };

  // Parse pasted CSV or Excel payload
  const handleRawCsvSubmit = () => {
    if (!rawCsvPaste.trim()) {
      alert("Please paste some comma-separated or tab-separated logistics data.");
      return;
    }

    try {
      const lines = rawCsvPaste.trim().split("\n");
      const headers = lines[0].toLowerCase().split(/[,\t]/);
      
      const newAwbs: AWB[] = [];
      const currentDay = new Date().toISOString().split("T")[0];

      for (let i = 1; i < lines.length; i++) {
        if (!lines[i].trim()) continue;
        const cols = lines[i].split(/[,\t]/);
        
        // Find positions of key columns
        const findVal = (names: string[], fallbackVal: string): string => {
          for (const name of names) {
            const idx = headers.findIndex(h => h.includes(name));
            if (idx !== -1 && cols[idx] !== undefined) return cols[idx].trim();
          }
          return fallbackVal;
        };

        const awbNumber = findVal(["awb", "consignment", "cn"], "AWB" + Math.floor(Math.random() * 900000 + 100000));
        const customerName = findVal(["customer", "client", "name"], "Unknown Client");
        const address = findVal(["address", "destination", "location"], "Direct Delivery Station");
        const branch = findVal(["branch", "station", "city"], "Chennai");
        const quantity = parseInt(findVal(["qty", "quantity", "pieces"], "1")) || 1;
        const weight = parseFloat(findVal(["wt", "weight", "mass"], "1.0")) || 1.0;
        const originalAmount = parseFloat(findVal(["amount", "price", "charge"], "500")) || 500;
        const bookingDate = findVal(["date", "booking"], currentDay);

        const deliveryBranch = cols[5] ? cols[5].trim() : branch;
        const odaOrLocal = cols[6] && cols[6].toLowerCase().includes("oda") ? "ODA" : "Local";

        newAwbs.push({
          bookingDate,
          awbNumber,
          customerName,
          customerAddress: address,
          deliveryBranch,
          odaOrLocal,
          boxQuantity: quantity,
          weight,
          actualAmount: originalAmount,
          additionalAmount: 0,
          totalAmount: originalAmount,
          approvalStatus: "None",
          adminRemark: "",
          branch,
          uploadDate: currentDay
        });
      }

      setAwbBookings((prev) => [...newAwbs, ...prev]);
      addLog("Upload", `Imported ${newAwbs.length} courier records from offline paste payload.`, "Admin Master");
      alert(`Successfully parsed and loaded ${newAwbs.length} AWB records into local Room DB.`);
      setRawCsvPaste("");
      setShowImportArea(false);
    } catch (err: any) {
      alert("Failed to parse paste data. Ensure the first line lists headers: Date, AWB, Customer, Address, Branch, Qty, Weight, Amount");
    }
  };

  // Parse dropped file using sheetJS XLSX (Excel parser)
  const handleExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const workbook = XLSX.read(bstr, { type: "binary" });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const data = XLSX.utils.sheet_to_json<any>(worksheet);

        const currentDay = new Date().toISOString().split("T")[0];
        const loaded: AWB[] = data.map((row: any) => {
          const branchVal = row["Branch"] || row["branch"] || "Chennai";
          const dateVal = row["Booking Date"] || row["bookingDate"] || currentDay;
          const awbVal = row["AWB Number"] || row["awbNumber"] || `AWB${Math.floor(Math.random() * 90000 + 10000)}`;
          const custVal = row["Customer Name"] || row["customerName"] || "Direct Consignee";
          const addrVal = row["Customer Address"] || row["customerAddress"] || "Counter Delivery";
          const deliveryVal = row["Delivery Branch"] || row["deliveryBranch"] || "Chennai";
          const odaVal = (row["ODA / Local"] || row["odaOrLocal"] || "Local") === "ODA" ? "ODA" : "Local";
          const qtyVal = parseInt(row["Box Quantity"] || row["boxQuantity"]) || 1;
          const wtVal = parseFloat(row["Weight"] || row["weight"]) || 1.0;
          const actualAmt = parseFloat(row["Actual Amount"] || row["actualAmount"]) || 500;
          const addAmt = parseFloat(row["Additional Amount"] || row["additionalAmount"]) || 0;
          const totalAmt = actualAmt + addAmt;
          const appStatus = row["Approval Status"] || "None";
          const admRemark = row["Admin Remark"] || "";

          return {
            branch: String(branchVal),
            bookingDate: String(dateVal),
            awbNumber: String(awbVal),
            customerName: String(custVal),
            customerAddress: String(addrVal),
            deliveryBranch: String(deliveryVal),
            odaOrLocal: odaVal,
            boxQuantity: qtyVal,
            weight: wtVal,
            actualAmount: actualAmt,
            additionalAmount: addAmt,
            totalAmount: totalAmt,
            approvalStatus: appStatus as "Pending" | "Approved" | "Rejected" | "None",
            adminRemark: admRemark,
            uploadDate: currentDay
          };
        });

        setAwbBookings((prev) => [...loaded, ...prev]);
        addLog("Upload", `Uploaded Excel spreadsheet: ${file.name} (${loaded.length} bookings)`, "Admin Mobile");
        alert(`Offline Excel Engine parsed ${loaded.length} bookings successfully!`);
      } catch (err) {
        alert("Error parsing Excel file. Please ensure columns match the sample template layout.");
      }
    };
    reader.readAsBinaryString(file);
  };

  // Simulated Wireless Device Hotspot Synchronization (addresses the user's connectivity warning!)
  const triggerWifiHotspotSync = () => {
    setIsSyncing(true);
    addLog("Sync", "Admin turned on Wi-Fi Local Hotspot. Broadcasting secure room credentials.", "Admin Mobile");
    setTimeout(() => {
      setIsSyncing(false);
      setSyncSuccessMsg("Synchronized 100% with Branch employee handheld devices locally!");
      addLog("Sync", "Branch Handsets updated with the latest approved budgets.", "System Local Net");
      setTimeout(() => setSyncSuccessMsg(""), 3000);
    }, 2000);
  };

  // Export database state to phone as a backup JSON file
  const backupLocalDatabase = () => {
    const backupObj = {
      version: "SVG_SMART_APP_V1.0",
      timestamp: new Date().toISOString(),
      employees,
      awbBookings,
      approvalRequests
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(backupObj));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `svg_offline_db_backup_${new Date().toISOString().split("T")[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    addLog("Backup", "Created offline backup file inside local phone storage path.", "Admin Mobile");
  };

  // Restore database state from local JSON backup file
  const handleRestoreDatabase = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    const fileReader = new FileReader();
    fileReader.onload = (evt) => {
      try {
        const parsed = JSON.parse(evt.target?.result as string);
        if (parsed.version !== "SVG_SMART_APP_V1.0") {
          throw new Error("Invalid file signature. Not an SVG Smart Approval Backup!");
        }

        if (parsed.employees) setEmployees(parsed.employees);
        if (parsed.awbBookings) setAwbBookings(parsed.awbBookings);
        if (parsed.approvalRequests) setApprovalRequests(parsed.approvalRequests);

        addLog("Backup", `Restored database completely from backup timestamp: ${parsed.timestamp}`, "Admin Mobile");
        alert("Database restore completed successfully! Local tables re-seeded.");
      } catch (err: any) {
        alert("Restore failed: " + err.message);
      }
    };
    fileReader.readAsText(files[0]);
  };

  // Export beautifully formatted PDF Reports using modular ReportEngine
  const triggerPDFExport = () => {
    generatePDFReport(
      filteredAwbs,
      deviceRole === "Admin" ? `Admin Master Ledger - Branch ${branchFilter}` : `Branch ${branchLoggedInUser?.branchName} Ledger`,
      `Date Filter: ${dateFilter} | Status Filter: ${statusFilter}`
    );
    addLog("Sync", "Exported custom PDF ledger report.", deviceRole === "Admin" ? "Admin Handset" : branchLoggedInUser?.employeeId || "Branch");
  };

  // Export ledger to real Excel XLSX workbook using modular ReportEngine
  const triggerExcelExport = () => {
    generateExcelReport(
      filteredAwbs,
      deviceRole === "Admin" ? `Master_Branch_${branchFilter}` : `Branch_${branchLoggedInUser?.branchName}`
    );
    addLog("Sync", "Compiled excel spreadsheet for download.", deviceRole === "Admin" ? "Admin Handset" : branchLoggedInUser?.employeeId || "Branch");
  };

  // Filter and Search Engine (Highly optimized for large records)
  const filteredAwbs = useMemo(() => {
    return awbBookings.filter((awb) => {
      // 1. Branch scoping protection (Branch employees can ONLY see their own branch)
      if (deviceRole === "Branch" && branchLoggedInUser) {
        if (awb.branch.toLowerCase() !== branchLoggedInUser.branchName.toLowerCase()) {
          return false;
        }
      } else if (deviceRole === "Admin" && branchFilter !== "All") {
        if (awb.branch.toLowerCase() !== branchFilter.toLowerCase()) {
          return false;
        }
      }

      // 2. Search query matcher - Support AWB, POD, Customer, Address, Delivery Branch, ODA / Local
      const query = searchQuery.trim().toLowerCase();
      if (query) {
        const matchesAwb = awb.awbNumber.toLowerCase().includes(query);
        const matchesCust = awb.customerName.toLowerCase().includes(query);
        const matchesAddr = awb.customerAddress.toLowerCase().includes(query);
        const matchesDeliv = awb.deliveryBranch.toLowerCase().includes(query);
        const matchesOda = awb.odaOrLocal.toLowerCase().includes(query);
        const matchesDate = awb.bookingDate.includes(query);
        
        if (!matchesAwb && !matchesCust && !matchesAddr && !matchesDeliv && !matchesOda && !matchesDate) {
          return false;
        }
      }

      // 3. Status filter
      if (statusFilter !== "All") {
        if (awb.approvalStatus !== statusFilter) return false;
      }

      // 4. Date filter
      if (dateFilter !== "All") {
        const todayStr = "2026-07-16";
        const yesterdayStr = "2026-07-15";
        if (dateFilter === "Today" && awb.bookingDate !== todayStr) return false;
        if (dateFilter === "Yesterday" && awb.bookingDate !== yesterdayStr) return false;
      }

      return true;
    });
  }, [awbBookings, searchQuery, statusFilter, dateFilter, deviceRole, branchLoggedInUser, branchFilter]);

  // Bulk Select & Delete state computations
  const selectedCount = useMemo(() => {
    return filteredAwbs.filter((awb) => !!selectedAwbNumbers[awb.awbNumber]).length;
  }, [filteredAwbs, selectedAwbNumbers]);

  const isAllFilteredSelected = useMemo(() => {
    if (filteredAwbs.length === 0) return false;
    return filteredAwbs.every((awb) => !!selectedAwbNumbers[awb.awbNumber]);
  }, [filteredAwbs, selectedAwbNumbers]);

  const handleToggleSelectAll = () => {
    if (isAllFilteredSelected) {
      setSelectedAwbNumbers((prev) => {
        const next = { ...prev };
        filteredAwbs.forEach((awb) => {
          delete next[awb.awbNumber];
        });
        return next;
      });
    } else {
      setSelectedAwbNumbers((prev) => {
        const next = { ...prev };
        filteredAwbs.forEach((awb) => {
          next[awb.awbNumber] = true;
        });
        return next;
      });
    }
  };

  const handleBulkDelete = () => {
    const awbsToDelete = filteredAwbs.filter((awb) => !!selectedAwbNumbers[awb.awbNumber]).map((awb) => awb.awbNumber);
    if (awbsToDelete.length === 0) return;

    if (window.confirm(`Are you sure you want to delete ${awbsToDelete.length} selected consignment record(s)?`)) {
      setAwbBookings((prev) => prev.filter((awb) => !selectedAwbNumbers[awb.awbNumber]));
      
      setSelectedAwbNumbers((prev) => {
        const next = { ...prev };
        awbsToDelete.forEach((id) => {
          delete next[id];
        });
        return next;
      });

      if (selectedAwb && awbsToDelete.includes(selectedAwb.awbNumber)) {
        setSelectedAwb(null);
      }

      addLog("Sync", `Bulk deleted ${awbsToDelete.length} consignment entries from local database.`, "Admin Mobile", "warning");
    }
  };

  // Download Kotlin Source code triggers
  const downloadKotlinCodeFile = (file: AndroidCodeFile) => {
    const element = document.createElement("a");
    const fileBlob = new Blob([file.content], { type: 'text/plain' });
    element.href = URL.createObjectURL(fileBlob);
    element.download = file.path.split("/").pop() || "code.kt";
    document.body.appendChild(element);
    element.click();
    element.remove();
  };

  if (showSplash) {
    return <Splash onComplete={() => setShowSplash(false)} />;
  }

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-all duration-300 ${
      isDarkMode 
        ? "bg-slate-950 text-slate-100 dark" 
        : "bg-slate-50 text-slate-800 light"
    }`} id="root-layout">
      
      {/* Top Main Navigation Header */}
      <header className={`border-b py-3 px-6 sticky top-0 z-50 flex flex-col md:flex-row items-center justify-between gap-4 transition-all duration-300 ${
        isDarkMode 
          ? "bg-slate-900 border-slate-800 text-slate-100" 
          : "bg-white border-slate-200 text-slate-800 shadow-sm"
      }`} id="master-header">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-blue-600 to-orange-500 flex items-center justify-center text-white font-extrabold shadow-lg shadow-blue-500/10">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <h1 className="font-display font-bold text-lg tracking-tight flex items-center gap-2">
              SVG Smart Extra Approval System
              <span className="text-[10px] font-mono bg-orange-600 text-white font-semibold px-2 py-0.5 rounded-full uppercase tracking-wider">
                100% Offline Emulator
              </span>
            </h1>
            <p className={`text-xs ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>
              Jetpack Compose + Room Local Encrypted SQLite Architecture. Pure Native Simulation Hub.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => { setActiveTab("simulator"); setShowSettingsPanel(false); }}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "simulator"
                ? "bg-blue-600 text-white shadow-md shadow-blue-600/20"
                : isDarkMode
                  ? "bg-slate-800 hover:bg-slate-700 text-slate-300"
                  : "bg-slate-100 hover:bg-slate-200 text-slate-600"
            }`}
          >
            <Smartphone className="h-3.5 w-3.5" /> Interactive Sandbox
          </button>
          
          <button
            onClick={() => { setActiveTab("kotlin_hub"); setShowSettingsPanel(false); }}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "kotlin_hub"
                ? "bg-blue-600 text-white shadow-md shadow-blue-600/20"
                : isDarkMode
                  ? "bg-slate-800 hover:bg-slate-700 text-slate-300"
                  : "bg-slate-100 hover:bg-slate-200 text-slate-600"
            }`}
          >
            <FileCode className="h-3.5 w-3.5" /> Production Code Hub
          </button>

          <button
            onClick={() => { setActiveTab("about"); setShowSettingsPanel(false); }}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "about"
                ? "bg-blue-600 text-white shadow-md shadow-blue-600/20"
                : isDarkMode
                  ? "bg-slate-800 hover:bg-slate-700 text-slate-300"
                  : "bg-slate-100 hover:bg-slate-200 text-slate-600"
            }`}
          >
            <Info className="h-3.5 w-3.5" /> Architecture Spec
          </button>

          <div className="h-5 w-[1px] bg-slate-700 mx-1"></div>

          {/* Light/Dark Toggle Button */}
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={`p-2 rounded-lg text-xs transition-all cursor-pointer ${
              isDarkMode 
                ? "bg-slate-800 hover:bg-slate-700 text-amber-400" 
                : "bg-slate-100 hover:bg-slate-200 text-slate-600"
            }`}
            title={isDarkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
          >
            {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
        </div>
      </header>

      {/* Main Container Section */}
      <main className="flex-1 max-w-[1700px] w-full mx-auto p-4 lg:p-6 grid grid-cols-1 overflow-hidden" id="main-frame">
        
        <AnimatePresence mode="wait">
          
          {/* SIMULATOR SCREEN PANEL */}
          {activeTab === "simulator" && (
            <motion.div
              key="simulator-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch"
              id="sandbox-grid"
            >
              
              {/* Left Column (Lg: 4 columns): Controls and Logs Desk */}
              <div className="lg:col-span-4 flex flex-col gap-5" id="control-desk">
                
                {/* Simulated Local Connection Hub Card */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-blue-500/10 text-blue-400 flex items-center justify-center">
                        <Wifi className="h-4.5 w-4.5 led-blink" />
                      </div>
                      <div>
                        <h3 className="font-display font-bold text-sm">Offline Local Hotspot Sync</h3>
                        <p className="text-[10px] text-slate-400">Zero Cloud, Direct Device-to-Device Linking</p>
                      </div>
                    </div>
                    <span className="text-[10px] bg-slate-800 text-green-400 border border-green-400/20 px-2.5 py-0.5 rounded-full font-bold">
                      ACTIVE
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    Addresses: <strong className="text-orange-400">"सारा डेटा केवल Admin के मोबाइल में रहे"</strong>. 
                    The Admin starts a local WiFi hotspot and other devices push/pull bookings directly via local IP packets.
                  </p>

                  <div className="flex gap-2">
                    <button
                      onClick={triggerWifiHotspotSync}
                      disabled={isSyncing}
                      className="flex-1 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-semibold text-xs py-2 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 shadow-md shadow-blue-600/10 cursor-pointer"
                    >
                      <RefreshCw className={`h-3.5 w-3.5 ${isSyncing ? "animate-spin" : ""}`} />
                      {isSyncing ? "Syncing..." : "Broadcast WiFi Sync"}
                    </button>
                    
                    <button
                      onClick={backupLocalDatabase}
                      title="Save encrypted backup package"
                      className="bg-slate-800 hover:bg-slate-700 text-slate-200 p-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-all cursor-pointer border border-slate-700"
                    >
                      <Database className="h-3.5 w-3.5 text-blue-400" /> Backup
                    </button>
                  </div>

                  {syncSuccessMsg && (
                    <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-3 text-xs text-green-400 flex items-center gap-2 animate-bounce">
                      <CheckCircle className="h-4 w-4 shrink-0" />
                      {syncSuccessMsg}
                    </div>
                  )}
                </div>

                {/* Device Selector Controller */}
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
                  <h3 className="font-display font-bold text-sm flex items-center gap-2">
                    <Sliders className="h-4 w-4 text-orange-400" />
                    Handset Device Switcher
                  </h3>
                  <p className="text-xs text-slate-400">
                    Switch between Admin mobile view and Branch user mobile view to test both perspectives of this local system:
                  </p>

                  <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
                    <button
                      onClick={() => setDeviceRole("Admin")}
                      className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        deviceRole === "Admin"
                          ? "bg-blue-600 text-white shadow-md shadow-blue-500/20"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      <Lock className="h-3.5 w-3.5" /> Admin Handset
                    </button>
                    <button
                      onClick={() => setDeviceRole("Branch")}
                      className={`py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        deviceRole === "Branch"
                          ? "bg-orange-600 text-white shadow-md shadow-orange-500/20"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      <UserCheck className="h-3.5 w-3.5" /> Branch Handset
                    </button>
                  </div>

                  {/* Device Status indicators */}
                  <div className="bg-slate-950/60 rounded-xl p-3.5 border border-slate-800/80 text-xs flex flex-col gap-2">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Active Simulated Role:</span>
                      <strong className={`font-bold uppercase ${deviceRole === "Admin" ? "text-blue-400" : "text-orange-400"}`}>
                        {deviceRole === "Admin" ? "Master Admin" : "Branch Desk User"}
                      </strong>
                    </div>
                    {deviceRole === "Branch" && (
                      <div className="flex justify-between items-center border-t border-slate-800/40 pt-1.5">
                        <span className="text-slate-400">Simulated Terminal Location:</span>
                        <span className="text-white font-medium bg-slate-800 px-2 py-0.5 rounded text-[10px]">
                          {branchLoggedInUser ? branchLoggedInUser.branchName : "Not Logged In"}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Real-time SQLite Local Logs */}
                <div className={`border rounded-2xl p-5 shadow-xl flex-1 flex flex-col gap-3 min-h-[250px] max-h-[400px] transition-all duration-300 ${
                  isDarkMode 
                    ? "bg-slate-900 border-slate-800 text-slate-100" 
                    : "bg-white border-slate-200 text-slate-800 shadow-sm"
                }`}>
                  <div className="flex items-center justify-between">
                    <h3 className="font-display font-bold text-sm flex items-center gap-2">
                      <Layers className="h-4 w-4 text-orange-400" />
                      SQLite DB Transaction Logs
                    </h3>
                    <button
                      onClick={() => setSyncLogs([])}
                      className={`text-[10px] cursor-pointer font-medium transition-colors ${
                        isDarkMode 
                          ? "text-slate-500 hover:text-slate-300" 
                          : "text-slate-400 hover:text-slate-600"
                      }`}
                    >
                      Clear Log
                    </button>
                  </div>

                  <div className="flex-1 overflow-y-auto pr-1 space-y-2">
                    {syncLogs.length === 0 ? (
                      <div className="text-center py-8 text-slate-600 text-xs">No transactions in current local session.</div>
                    ) : (
                      syncLogs.map((log) => {
                        const status = log.status || "success";
                        let icon = <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5 animate-pulse" />;
                        let cardClass = isDarkMode
                          ? "bg-slate-950 border-slate-800/60"
                          : "bg-slate-50 border-slate-200/80";
                        
                        if (status === "warning") {
                          icon = <AlertCircle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />;
                          cardClass = isDarkMode
                            ? "bg-amber-950/10 border-amber-900/30"
                            : "bg-amber-50/40 border-amber-100";
                        } else if (status === "error") {
                          icon = <XCircle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />;
                          cardClass = isDarkMode
                            ? "bg-red-950/10 border-red-900/30"
                            : "bg-red-50/40 border-red-100";
                        } else if (status === "info") {
                          icon = <Info className="h-4 w-4 text-blue-500 shrink-0 mt-0.5" />;
                          cardClass = isDarkMode
                            ? "bg-blue-950/10 border-blue-900/30"
                            : "bg-blue-50/40 border-blue-100";
                        }

                        return (
                          <div
                            key={log.id}
                            className={`p-2.5 rounded-xl border text-[11px] flex gap-2.5 transition-all duration-200 hover:translate-x-0.5 ${cardClass}`}
                          >
                            {icon}
                            <div className="flex-1 flex flex-col gap-1">
                              <div className="flex justify-between items-center text-[10px]">
                                <span className={isDarkMode ? "text-slate-500" : "text-slate-400"}>
                                  {log.timestamp}
                                </span>
                                <span className={`font-mono px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                                  status === "success" 
                                    ? "text-emerald-500 bg-emerald-500/10" 
                                    : status === "warning"
                                      ? "text-amber-500 bg-amber-500/10"
                                      : status === "error"
                                        ? "text-red-500 bg-red-500/10"
                                        : "text-blue-500 bg-blue-500/10"
                                }`}>
                                  {log.type}
                                </span>
                              </div>
                              <p className={isDarkMode ? "text-slate-300" : "text-slate-700 font-medium"}>
                                {log.message}
                              </p>
                              <div className={`text-[9px] text-right italic ${isDarkMode ? "text-slate-500" : "text-slate-400"}`}>
                                - {log.sender}
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

              </div>

              {/* Right/Center Column (Lg: 8 columns): Interactive Mobile Frame Sandbox */}
              <div className="lg:col-span-8 flex flex-col" id="simulator-phone-stage">
                
                {/* Beautiful Mock Handset Frame Wrapper */}
                <div className="bg-slate-900 border-4 border-slate-800 rounded-[32px] overflow-hidden flex flex-col min-h-[750px] shadow-2xl relative" id="mock-smartphone">
                  
                  {/* Top Phone Ear Speaker & Notch Camera banner */}
                  <div className="bg-slate-950 py-2.5 flex justify-center items-center gap-1.5 relative z-20">
                    <div className="h-4 w-20 rounded-full bg-slate-900 flex items-center justify-center border border-slate-800">
                      <div className="h-1.5 w-1.5 rounded-full bg-slate-950" />
                    </div>
                    <div className="absolute right-5 top-2.5 flex items-center gap-1.5 text-[10px] font-mono text-slate-500">
                      <span>LTE (Off)</span>
                      <div className="h-2.5 w-4 bg-slate-700 rounded-sm relative overflow-hidden">
                        <div className="h-full w-4/5 bg-slate-400 rounded-sm" />
                      </div>
                    </div>
                  </div>

                  {/* Android Content Canvas (Blue & Orange Palette theme) */}
                  <div className="flex-1 bg-slate-950 overflow-y-auto flex flex-col relative" id="smartphone-screen-canvas">
                    
                    {/* Active User Header inside the simulated screen */}
                    <div className="bg-gradient-to-r from-blue-900 to-slate-900 py-3 px-5 border-b border-slate-800 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="h-3 w-3 rounded-full bg-green-500 animate-pulse" />
                        <span className="text-xs font-bold text-slate-200">
                          {deviceRole === "Admin" ? "Master Admin Handset (Active)" : `Branch Terminal: ${branchLoggedInUser?.branchName || "Awaiting Login"}`}
                        </span>
                      </div>
                      
                      {(deviceRole === "Admin" ? adminLoggedIn : branchLoggedInUser !== null) && (
                        <button
                          onClick={() => {
                            setAdminLoggedIn(false);
                            setBranchLoggedInUser(null);
                            setLoginError("");
                            setSelectedAwb(null);
                          }}
                          className="bg-red-500/10 hover:bg-red-500/20 text-red-400 font-bold px-2 py-1 rounded text-[10px] flex items-center gap-1 cursor-pointer"
                        >
                          <LogOut className="h-3 w-3" /> Log Out
                        </button>
                      )}
                    </div>

                    {/* SCREEN ROUTE DISPATCHER */}
                    
                    {/* 1. ADMIN NOT LOGGED IN SCREEN */}
                    {deviceRole === "Admin" && !adminLoggedIn && (
                      <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
                        <div className="h-16 w-16 bg-blue-600/10 rounded-2xl border border-blue-500/20 flex items-center justify-center text-blue-400 mb-4 shadow-lg shadow-blue-500/5">
                          <Lock className="h-8 w-8" />
                        </div>
                        <h2 className="font-display font-extrabold text-lg text-white">Admin Master Keypad</h2>
                        <p className="text-xs text-slate-400 max-w-xs mt-1 mb-6">
                          Enter the Admin passcode PIN to manage branch logins, approve extra surcharges, and audit PDF ledgers.
                        </p>

                        <form onSubmit={handleAdminLogin} className="w-full max-w-sm flex flex-col gap-3">
                          <div>
                            <input
                              type="password"
                              value={adminLoginInput}
                              onChange={(e) => setAdminLoginInput(e.target.value)}
                              placeholder="Enter Master Password PIN (9999)"
                              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-center text-sm font-mono tracking-widest text-white outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition-all"
                            />
                          </div>

                          {loginError && (
                            <div className="text-xs text-red-400 bg-red-500/5 border border-red-500/10 rounded-lg p-2.5">
                              {loginError}
                            </div>
                          )}

                          <button
                            type="submit"
                            className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-bold text-xs py-3 rounded-xl transition-all uppercase tracking-wider shadow-lg shadow-blue-600/10 cursor-pointer"
                          >
                            Authenticate Master SQLite Database
                          </button>
                        </form>

                        <div className="mt-8 text-[11px] text-slate-500">
                          Default Passcode: <span className="font-mono text-slate-400">9999</span> (Offline local encrypted vault)
                        </div>
                      </div>
                    )}

                    {/* 2. BRANCH NOT LOGGED IN SCREEN */}
                    {deviceRole === "Branch" && !branchLoggedInUser && (
                      <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
                        <div className="h-16 w-16 bg-orange-600/10 rounded-2xl border border-orange-500/20 flex items-center justify-center text-orange-400 mb-4 shadow-lg shadow-orange-500/5">
                          <UserCheck className="h-8 w-8" />
                        </div>
                        <h2 className="font-display font-extrabold text-lg text-white">Branch Handheld Login</h2>
                        <p className="text-xs text-slate-400 max-w-xs mt-1 mb-6">
                          Branch operators log in using Employee ID and 4-digit PIN to access local consignment lists.
                        </p>

                        <form onSubmit={handleBranchLogin} className="w-full max-w-sm flex flex-col gap-3">
                          <div className="flex flex-col gap-1 text-left">
                            <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Select Employee ID</label>
                            <select
                              value={branchLoginId}
                              onChange={(e) => setBranchLoginId(e.target.value)}
                              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:ring-2 focus:ring-orange-600"
                            >
                              {employees.map((emp) => (
                                <option key={emp.employeeId} value={emp.employeeId}>
                                  {emp.employeeId} ({emp.branchName})
                                </option>
                              ))}
                            </select>
                          </div>

                          <div className="flex flex-col gap-1 text-left">
                            <label className="text-[10px] uppercase font-bold tracking-wider text-slate-400">4-Digit security PIN</label>
                            <input
                              type="password"
                              maxLength={4}
                              value={branchLoginPin}
                              onChange={(e) => setBranchLoginPin(e.target.value)}
                              placeholder="e.g. 1234, 5678"
                              className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-center font-mono tracking-widest text-white outline-none focus:ring-2 focus:ring-orange-600"
                            />
                          </div>

                          {loginError && (
                            <div className="text-xs text-red-400 bg-red-500/5 border border-red-500/10 rounded-lg p-2">
                              {loginError}
                            </div>
                          )}

                          <button
                            type="submit"
                            className="w-full bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 text-white font-bold text-xs py-3 rounded-xl transition-all uppercase tracking-wider shadow-lg shadow-orange-600/10 cursor-pointer mt-2"
                          >
                            Authenticate Branch Handset
                          </button>
                        </form>

                        <div className="mt-8 bg-slate-900/60 border border-slate-800 rounded-xl p-3 text-left w-full max-w-sm">
                          <span className="block text-[10px] text-orange-400 font-extrabold uppercase tracking-widest">Mock Handset Registry PINs:</span>
                          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-[11px] text-slate-400 mt-1 font-mono">
                            {employees.map(emp => (
                              <div key={emp.employeeId}>
                                {emp.employeeId}: <span className="text-white">{emp.passwordPin}</span> ({emp.branchName})
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* 3. LOGGED IN ADMIN WORKSPACE VIEW */}
                    {deviceRole === "Admin" && adminLoggedIn && (
                      <div className="flex-1 flex flex-col p-4 gap-4" id="admin-screen-root">
                        
                        {/* Quick Statistics Banner inside phone */}
                        <div className="grid grid-cols-3 gap-2">
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-2 text-center">
                            <span className="block text-[9px] text-slate-400 uppercase">Bookings</span>
                            <span className="text-xs font-extrabold text-blue-400">{awbBookings.length} AWBs</span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-2 text-center">
                            <span className="block text-[9px] text-slate-400 uppercase">Pending</span>
                            <span className="text-xs font-extrabold text-amber-400">
                              {approvalRequests.filter(r => r.status === "Pending").length} REQs
                            </span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-2 text-center">
                            <span className="block text-[9px] text-slate-400 uppercase">Total Expenses</span>
                            <span className="text-xs font-extrabold text-green-400">₹{totalAmountBilled}</span>
                          </div>
                        </div>

                        {/* Excel/CSV Import and Admin Action Buttons */}
                        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col gap-2">
                          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Admin Control Board</span>
                          
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              onClick={downloadSampleExcel}
                              className="col-span-2 bg-emerald-600/10 hover:bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 rounded-lg p-2.5 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                              title="Download professional template format"
                            >
                              <Download className="h-3.5 w-3.5 text-emerald-400" /> Download Sample Excel (.xlsx)
                            </button>

                            <button
                              onClick={() => {
                                fileInputRef.current?.click();
                              }}
                              className="bg-blue-600/10 hover:bg-blue-600/20 border border-blue-500/30 text-blue-400 rounded-lg p-2 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                            >
                              <FileSpreadsheet className="h-3.5 w-3.5" /> Import Excel
                            </button>
                            <input
                              type="file"
                              ref={fileInputRef}
                              onChange={handleExcelImport}
                              accept=".xlsx,.xls,.csv"
                              className="hidden"
                            />

                            <button
                              onClick={() => setShowImportArea(!showImportArea)}
                              className="bg-orange-600/10 hover:bg-orange-600/20 border border-orange-500/30 text-orange-400 rounded-lg p-2 text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                            >
                              <Plus className="h-3.5 w-3.5" /> Paste Raw Cargo
                            </button>
                          </div>

                          <div className="grid grid-cols-2 gap-2 mt-1">
                            <button
                              onClick={generateLargeDatabase}
                              className="bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg p-2 text-[10px] font-semibold flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <PlusCircle className="h-3 w-3 text-blue-400" /> Inject 1.5k Bookings
                            </button>
                            <button
                              onClick={() => setShowSettingsPanel(!showSettingsPanel)}
                              className="bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg p-2 text-[10px] font-semibold flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <Settings className="h-3 w-3 text-orange-400" /> Manage Staff ID
                            </button>
                          </div>
                        </div>

                        {/* Paste Import Modal segment */}
                        {showImportArea && (
                          <div className="bg-slate-900 border border-orange-500/30 rounded-xl p-3 flex flex-col gap-2 animate-fade-in">
                            <span className="text-[10px] font-bold text-orange-400">Paste tab-separated booking rows:</span>
                            <textarea
                              rows={3}
                              value={rawCsvPaste}
                              onChange={(e) => setRawCsvPaste(e.target.value)}
                              placeholder="Booking Date&#9;AWB&#9;Customer Name&#9;Address&#9;Branch&#9;Qty&#9;Weight&#9;Original Amount"
                              className="w-full bg-slate-950 text-xs font-mono p-2 border border-slate-800 rounded text-white focus:outline-none"
                            />
                            <div className="flex justify-end gap-2 text-[10px]">
                              <button onClick={() => setShowImportArea(false)} className="text-slate-400">Cancel</button>
                              <button onClick={handleRawCsvSubmit} className="bg-orange-600 text-white font-bold px-3 py-1 rounded">Import DB</button>
                            </div>
                          </div>
                        )}

                        {/* Manage staff logins expansion drawer */}
                        {showSettingsPanel && (
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col gap-3">
                            <div className="flex justify-between items-center border-b border-slate-800 pb-1.5">
                              <span className="text-xs font-extrabold text-blue-400 uppercase tracking-widest">Registered Employee IDs</span>
                              <button onClick={() => setShowSettingsPanel(false)} className="text-slate-400 hover:text-slate-200 text-xs">Close</button>
                            </div>

                            {/* Registered staff table */}
                            <div className="space-y-1.5 max-h-[140px] overflow-y-auto">
                              {employees.map((emp) => (
                                <div key={emp.employeeId} className="flex justify-between items-center text-xs bg-slate-950 p-2 rounded border border-slate-850">
                                  <div>
                                    <strong className="text-white font-mono">{emp.employeeId}</strong>
                                    <span className="text-slate-500 ml-1.5 font-bold">({emp.branchName})</span>
                                    <span className="text-[10px] text-slate-400 block font-mono">PIN: {emp.passwordPin}</span>
                                  </div>
                                  <div className="flex items-center gap-1.5">
                                    <button
                                      onClick={() => toggleEmployeeStatus(emp.employeeId)}
                                      className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                                        emp.status === "Active" ? "bg-green-500/15 text-green-400" : "bg-red-500/15 text-red-400"
                                      }`}
                                    >
                                      {emp.status}
                                    </button>
                                    <button onClick={() => deleteEmployee(emp.employeeId)} className="text-red-400 hover:text-red-200">
                                      <Trash2 className="h-3 w-3" />
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>

                            {/* Register new form */}
                            <form onSubmit={handleAddEmployee} className="border-t border-slate-800 pt-2 flex flex-col gap-2">
                              <span className="text-[10px] font-bold text-slate-400 uppercase">Create Branch ID</span>
                              <div className="grid grid-cols-3 gap-1.5">
                                <input
                                  type="text"
                                  placeholder="ID (e.g. BI01)"
                                  value={newEmpId}
                                  onChange={(e) => setNewEmpId(e.target.value)}
                                  className="bg-slate-950 text-xs p-1.5 border border-slate-800 rounded text-white"
                                />
                                <input
                                  type="text"
                                  placeholder="Branch Name"
                                  value={newEmpBranch}
                                  onChange={(e) => setNewEmpBranch(e.target.value)}
                                  className="bg-slate-950 text-xs p-1.5 border border-slate-800 rounded text-white"
                                />
                                <input
                                  type="password"
                                  maxLength={4}
                                  placeholder="4-digit PIN"
                                  value={newEmpPin}
                                  onChange={(e) => setNewEmpPin(e.target.value)}
                                  className="bg-slate-950 text-xs p-1.5 border border-slate-800 rounded text-white font-mono"
                                />
                              </div>
                              {newEmpError && <span className="text-[10px] text-red-400 font-mono">{newEmpError}</span>}
                              <button type="submit" className="bg-blue-600 text-white font-bold text-xs py-1.5 rounded transition-all">
                                Add Staff Member
                              </button>
                            </form>
                          </div>
                        )}

                        {/* Search, Filter & Consignment Ledger List */}
                        <div className="flex-1 flex flex-col gap-3 min-h-[350px]">
                          
                          {/* Search segment */}
                          <div className="grid grid-cols-2 gap-2">
                            <div className="col-span-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2 flex-1">
                                <Search className="h-4 w-4 text-slate-500" />
                                <input
                                  type="text"
                                  value={searchQuery}
                                  onChange={(e) => setSearchQuery(e.target.value)}
                                  placeholder="Search by AWB, customer, address, delivery branch, ODA..."
                                  className="bg-transparent border-none text-xs text-white outline-none w-full"
                                />
                              </div>
                              <button
                                onClick={() => setShowQRScanner(true)}
                                className="bg-blue-600 hover:bg-blue-500 text-white p-1.5 px-3 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md shadow-blue-600/10 transition-all hover:scale-105 active:scale-95 shrink-0"
                                title="Scan AWB QR/Barcode Label"
                              >
                                <Camera className="h-3.5 w-3.5" />
                                <span>Scan Label</span>
                              </button>
                            </div>
                            
                            <select
                              value={statusFilter}
                              onChange={(e: any) => setStatusFilter(e.target.value)}
                              className="bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 p-2 outline-none cursor-pointer w-full"
                            >
                              <option value="All">All Statuses</option>
                              <option value="None">Normal (None)</option>
                              <option value="Pending">Pending</option>
                              <option value="Approved">Approved</option>
                              <option value="Rejected">Rejected</option>
                            </select>

                            <select
                              value={branchFilter}
                              onChange={(e) => setBranchFilter(e.target.value)}
                              className="bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 p-2 outline-none cursor-pointer w-full"
                            >
                              <option value="All">All Branches</option>
                              {allBranches.map((branch) => (
                                <option key={branch} value={branch}>
                                  {branch}
                                </option>
                              ))}
                            </select>
                          </div>

                          {/* Quick statistics ledger outputs & Export report links */}
                          <div className="flex justify-between items-center text-xs text-slate-400 px-1 border-b border-slate-800 pb-1.5">
                            <span>Showing {filteredAwbs.length} courier entries</span>
                            <div className="flex gap-2">
                              <button
                                onClick={triggerPDFExport}
                                title="Export detailed audit ledger PDF"
                                className="text-red-400 hover:text-red-300 font-bold flex items-center gap-1"
                              >
                                <FileDown className="h-3.5 w-3.5" /> PDF
                              </button>
                              <button
                                onClick={triggerExcelExport}
                                title="Export master spreadsheets Excel"
                                className="text-green-400 hover:text-green-300 font-bold flex items-center gap-1"
                              >
                                <FileSpreadsheet className="h-3.5 w-3.5" /> Excel
                              </button>
                            </div>
                          </div>

                          {/* Bulk actions bar for Admin */}
                          {filteredAwbs.length > 0 && (
                            <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-2.5 flex justify-between items-center text-xs">
                              <div className="flex items-center gap-2">
                                <input
                                  type="checkbox"
                                  id="select-all-checkbox"
                                  checked={isAllFilteredSelected}
                                  onChange={handleToggleSelectAll}
                                  className="h-3.5 w-3.5 rounded border-slate-700 bg-slate-950 text-blue-600 focus:ring-blue-500 cursor-pointer text-xs"
                                />
                                <label htmlFor="select-all-checkbox" className="text-slate-300 font-semibold cursor-pointer select-none">
                                  Select All
                                </label>
                              </div>
                              {selectedCount > 0 && (
                                <button
                                  onClick={handleBulkDelete}
                                  className="bg-red-600/20 hover:bg-red-600/30 border border-red-500/30 text-red-400 font-bold px-3 py-1 rounded-lg flex items-center gap-1 cursor-pointer transition-all active:scale-95 text-[11px]"
                                >
                                  <Trash2 className="h-3 w-3" /> Delete Selected ({selectedCount})
                                </button>
                              )}
                            </div>
                          )}

                          {/* Booking Records List scrolling pane */}
                          <div className="flex-1 overflow-y-auto space-y-2.5 max-h-[380px] pr-1">
                            {filteredAwbs.length === 0 ? (
                              <div className="text-center py-12 text-slate-500 text-xs">
                                No records matched query indexes. Try injecting mock payloads.
                              </div>
                            ) : (
                              filteredAwbs.map((awb) => (
                                <div
                                  key={awb.awbNumber}
                                  onClick={() => setSelectedAwb(awb)}
                                  className={`bg-slate-900 border rounded-xl p-3 flex flex-col gap-2 transition-all cursor-pointer ${
                                    selectedAwb?.awbNumber === awb.awbNumber ? "border-blue-500 bg-slate-900" : "border-slate-800 hover:border-slate-700 bg-slate-900/60"
                                  }`}
                                >
                                  <div className="flex justify-between items-center">
                                    <div className="flex items-center gap-2">
                                      <input
                                        type="checkbox"
                                        checked={!!selectedAwbNumbers[awb.awbNumber]}
                                        onClick={(e) => e.stopPropagation()}
                                        onChange={(e) => {
                                          setSelectedAwbNumbers((prev) => ({
                                            ...prev,
                                            [awb.awbNumber]: e.target.checked,
                                          }));
                                        }}
                                        className="h-3.5 w-3.5 rounded border-slate-700 bg-slate-950 text-blue-600 focus:ring-blue-500 cursor-pointer"
                                      />
                                      <span className="font-mono text-xs font-bold text-white">{awb.awbNumber}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <span className="text-[10px] text-slate-400 font-mono">{awb.bookingDate}</span>
                                      
                                      {/* Status tag */}
                                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                                        awb.approvalStatus === "Approved" ? "bg-green-500/10 text-green-400 border border-green-500/20" :
                                        awb.approvalStatus === "Rejected" ? "bg-red-500/10 text-red-400 border border-red-500/20" :
                                        awb.approvalStatus === "Pending" ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" :
                                        "bg-slate-800 text-slate-400"
                                      }`}>
                                        {awb.approvalStatus === "None" ? "Standard" : awb.approvalStatus}
                                      </span>
                                    </div>
                                  </div>

                                  <div className="grid grid-cols-2 text-xs">
                                    <div>
                                      <span className="text-[10px] text-slate-500 block">Customer</span>
                                      <span className="text-slate-300 font-medium truncate max-w-full block">{awb.customerName}</span>
                                    </div>
                                    <div className="text-right">
                                      <span className="text-[10px] text-slate-500 block">Station Location</span>
                                      <span className="text-slate-300 font-medium">{awb.branch}</span>
                                    </div>
                                  </div>

                                  <div className="flex justify-between items-center text-[11px] border-t border-slate-800/40 pt-1.5 mt-1">
                                    <span className="text-slate-400">Freight Cost: ₹{awb.actualAmount}</span>
                                    {awb.additionalAmount > 0 && (
                                      <span className="text-green-400 font-bold">Extra Surcharge: +₹{awb.additionalAmount}</span>
                                    )}
                                    <span className="text-white font-extrabold font-mono">Total: ₹{awb.totalAmount}</span>
                                  </div>
                                </div>
                              ))
                            )}
                          </div>

                        </div>

                      </div>
                    )}

                    {/* 4. LOGGED IN BRANCH WORKSPACE VIEW */}
                    {deviceRole === "Branch" && branchLoggedInUser && (
                      <div className="flex-1 flex flex-col p-4 gap-4" id="branch-screen-root">
                        
                        {/* Branch Title & Quick Summary of Today's entries */}
                        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex justify-between items-center">
                          <div>
                            <span className="text-[10px] uppercase font-bold text-orange-400 tracking-wider">Branch Console</span>
                            <h3 className="font-display font-extrabold text-sm text-white">{branchLoggedInUser.branchName} Desk</h3>
                          </div>
                          <div className="text-right">
                            <span className="block text-[10px] text-slate-400 uppercase">Branch Code</span>
                            <strong className="text-xs text-white font-mono">{branchLoggedInUser.employeeId}</strong>
                          </div>
                        </div>

                        {/* Top Cards Grid */}
                        <div className="grid grid-cols-2 gap-2">
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5">
                            <span className="block text-[9px] text-slate-400 uppercase">My Total CN</span>
                            <span className="text-base font-extrabold text-white">{filteredAwbs.length}</span>
                          </div>
                          <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5">
                            <span className="block text-[9px] text-slate-400 uppercase">Pending Requests</span>
                            <span className="text-base font-extrabold text-amber-400">
                              {approvalRequests.filter(r => r.employeeId === branchLoggedInUser.employeeId && r.status === "Pending").length}
                            </span>
                          </div>
                        </div>

                        {/* Search and Filters */}
                        <div className="flex gap-2 items-center">
                          <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 flex items-center gap-2">
                            <Search className="h-4 w-4 text-slate-500" />
                            <input
                              type="text"
                              value={searchQuery}
                              onChange={(e) => setSearchQuery(e.target.value)}
                              placeholder="Search My AWB Bookings..."
                              className="bg-transparent border-none text-xs text-white outline-none w-full"
                            />
                          </div>

                          {/* Camera QR Scanner Trigger Button */}
                          <button
                            onClick={() => setShowQRScanner(true)}
                            className="bg-orange-600 hover:bg-orange-500 text-white p-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-lg shadow-orange-600/10 transition-all hover:scale-105 active:scale-95 shrink-0"
                            title="Scan AWB QR/Barcode Label"
                          >
                            <Camera className="h-4 w-4" />
                            <span>Scan AWB</span>
                          </button>

                          <select
                            value={statusFilter}
                            onChange={(e: any) => setStatusFilter(e.target.value)}
                            className="bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 p-2.5 outline-none cursor-pointer"
                          >
                            <option value="All">All</option>
                            <option value="None">Normal</option>
                            <option value="Pending">Pending</option>
                            <option value="Approved">Approved</option>
                            <option value="Rejected">Rejected</option>
                          </select>
                        </div>

                        {/* Scrolling branch filtered list */}
                        <div className="flex-1 overflow-y-auto space-y-2 max-h-[350px]">
                          {filteredAwbs.length === 0 ? (
                            <div className="text-center py-12 text-slate-500 text-xs">
                              No records found for your branch station.
                            </div>
                          ) : (
                            filteredAwbs.map((awb) => (
                              <div
                                key={awb.awbNumber}
                                onClick={() => setSelectedAwb(awb)}
                                className={`bg-slate-900 border rounded-xl p-3 flex flex-col gap-2 transition-all cursor-pointer ${
                                  selectedAwb?.awbNumber === awb.awbNumber ? "border-orange-500 bg-slate-900" : "border-slate-800 hover:border-slate-700 bg-slate-900/60"
                                }`}
                              >
                                <div className="flex justify-between items-center">
                                  <span className="font-mono text-xs font-bold text-white">{awb.awbNumber}</span>
                                  <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                                    awb.approvalStatus === "Approved" ? "bg-green-500/10 text-green-400 border border-green-500/20" :
                                    awb.approvalStatus === "Rejected" ? "bg-red-500/10 text-red-400 border border-red-500/20" :
                                    awb.approvalStatus === "Pending" ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" :
                                    "bg-slate-850 text-slate-400"
                                  }`}>
                                    {awb.approvalStatus === "None" ? "Standard" : awb.approvalStatus}
                                  </span>
                                </div>

                                <div className="text-xs text-slate-300">
                                  <span className="text-[10px] text-slate-500 block">Customer</span>
                                  <span>{awb.customerName}</span>
                                </div>

                                <div className="flex justify-between items-center text-[11px] border-t border-slate-800/40 pt-1.5 mt-1">
                                  <span className="text-slate-400">Qty: {awb.boxQuantity} pcs ({awb.weight} kg)</span>
                                  <span className="text-white font-mono font-bold">₹{awb.totalAmount}</span>
                                </div>
                              </div>
                            ))
                          )}
                        </div>

                      </div>
                    )}

                    {/* AWB DETAILS BOTTOM COMPACT CARD - SHOWN WHEN ONE IS CLICKED */}
                    {selectedAwb && (
                      <div className="absolute bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-800 p-4 flex flex-col gap-3 rounded-t-2xl z-30 shadow-2xl animate-slide-up" id="awb-details-drawer">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[9px] bg-slate-800 text-slate-300 font-mono px-2 py-0.5 rounded-md uppercase">
                              {selectedAwb.branch} Location
                            </span>
                            <h3 className="font-display font-extrabold text-sm text-white mt-1">
                              Booking AWB: {selectedAwb.awbNumber}
                            </h3>
                          </div>
                          <button
                            onClick={() => setSelectedAwb(null)}
                            className="text-slate-500 hover:text-slate-300 p-1"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                          <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/50">
                            <span className="text-[9px] text-slate-500 block uppercase">Consignee Name</span>
                            <strong className="text-slate-200 block truncate">{selectedAwb.customerName}</strong>
                            <span className="text-[10px] text-slate-400 block truncate mt-0.5">{selectedAwb.customerAddress}</span>
                          </div>

                          <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/50 flex flex-col justify-between">
                            <div>
                              <span className="text-[9px] text-slate-500 block uppercase">Shipment Specs</span>
                              <strong className="text-slate-200">{selectedAwb.boxQuantity} items / {selectedAwb.weight} kg</strong>
                            </div>
                            <span className="text-[10px] text-slate-400 block mt-1">Date: {selectedAwb.bookingDate}</span>
                          </div>

                          {/* QR Code display card for testing camera scanning */}
                          <div className="bg-white p-2 rounded-xl flex flex-col items-center justify-center gap-1 border border-slate-800/50 relative shadow-sm group select-none">
                            {selectedAwbQrUrl ? (
                              <>
                                <img
                                  src={selectedAwbQrUrl}
                                  alt="AWB QR Code"
                                  className="h-16 w-16"
                                  referrerPolicy="no-referrer"
                                />
                                <span className="text-[8px] text-slate-500 font-mono font-bold uppercase tracking-tight">
                                  Scan to load
                                </span>
                              </>
                            ) : (
                              <div className="h-16 w-16 bg-slate-100 animate-pulse rounded" />
                            )}
                          </div>
                        </div>

                        {/* Surcharge breakdown or approval actions */}
                        <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 text-xs flex flex-col gap-1.5">
                          <div className="flex justify-between">
                            <span className="text-slate-400">Base Freight Cost:</span>
                            <span className="text-slate-200">₹{selectedAwb.actualAmount}</span>
                          </div>
                          
                          {selectedAwb.additionalAmount > 0 && (
                            <div className="flex justify-between text-green-400 font-bold border-t border-slate-800/45 pt-1">
                              <span>Approved Surcharges:</span>
                              <span>+₹{selectedAwb.additionalAmount}</span>
                            </div>
                          )}

                          <div className="flex justify-between font-extrabold text-sm text-white border-t border-slate-800 pt-1.5">
                            <span>Grand Total Invoice:</span>
                            <span className="text-blue-400 font-mono">₹{selectedAwb.totalAmount}</span>
                          </div>

                          {selectedAwb.adminRemark && (
                            <p className="text-[11px] text-orange-400 bg-orange-950/20 p-2 rounded border border-orange-900/30 mt-1 italic font-mono">
                              Admin Remark: "{selectedAwb.adminRemark}"
                            </p>
                          )}
                        </div>

                        {/* CONTEXTUAL ACTION KEYS */}
                        {deviceRole === "Branch" && branchLoggedInUser && selectedAwb.approvalStatus !== "Pending" && selectedAwb.approvalStatus !== "Approved" && (
                          <button
                            onClick={() => setShowRequestExtraModal(true)}
                            className="w-full bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 text-white font-bold text-xs py-2.5 rounded-xl transition-all uppercase cursor-pointer text-center"
                          >
                            Request Extra Approval Amount
                          </button>
                        )}

                        {deviceRole === "Admin" && adminLoggedIn && (
                          <div className="flex gap-2">
                            {approvalRequests.filter(r => r.awbNumber === selectedAwb.awbNumber && r.status === "Pending").map((req) => (
                              <div key={req.id} className="w-full flex gap-2">
                                <button
                                  onClick={() => {
                                    setSelectedRequestToDecide(req);
                                    setDecisionType("Approve");
                                    setDecisionApprovedAmount(String(req.requestedAmount));
                                    setDecisionAdminRemark("Approved extra logistics surcharges");
                                    setShowApprovalDialog(true);
                                  }}
                                  className="flex-1 bg-green-600 hover:bg-green-500 text-white font-bold text-xs py-2 rounded-lg cursor-pointer"
                                >
                                  Approve Extra ₹{req.requestedAmount}
                                </button>
                                <button
                                  onClick={() => {
                                    setSelectedRequestToDecide(req);
                                    setDecisionType("Reject");
                                    setDecisionAdminRemark("Surcharges rejected - standard rates apply");
                                    setShowApprovalDialog(true);
                                  }}
                                  className="flex-1 bg-red-600 hover:bg-red-500 text-white font-bold text-xs py-2 rounded-lg cursor-pointer"
                                >
                                  Reject Request
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                  </div>

                  {/* Phone Bottom Home bar indicator */}
                  <div className="bg-slate-950 py-3 flex justify-center items-center z-20">
                    <div className="h-1.5 w-28 rounded-full bg-slate-800" />
                  </div>

                </div>

              </div>

            </motion.div>
          )}

          {/* ENTERPRISE PRODUCTION CODE HUB PANEL */}
          {activeTab === "kotlin_hub" && (
            <motion.div
              key="kotlin-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch"
              id="kotlin-hub"
            >
              {/* Files Selection Menu Sidebar (Lg: 4 columns) */}
              <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
                
                {/* Platform Toggler Tabs */}
                <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <button
                    onClick={() => setCodeHubPlatform("android")}
                    className={`py-2 px-1 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                      codeHubPlatform === "android"
                        ? "bg-blue-600 text-white shadow-lg shadow-blue-600/10"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    Android Client
                  </button>
                  <button
                    onClick={() => setCodeHubPlatform("backend")}
                    className={`py-2 px-1 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                      codeHubPlatform === "backend"
                        ? "bg-blue-600 text-white shadow-lg shadow-blue-600/10"
                        : "text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    Laravel & MySQL
                  </button>
                </div>

                <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                  <div className="h-8 w-8 rounded-lg bg-orange-600/10 text-orange-400 flex items-center justify-center">
                    <FileCode className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <h3 className="font-display font-extrabold text-sm text-white">
                      {codeHubPlatform === "android" ? "Android Kotlin App" : "Laravel PHP Backend"}
                    </h3>
                    <p className="text-[10px] text-slate-400">
                      {codeHubPlatform === "android" ? "MVVM + Room Cache + Jetpack Compose" : "MySQL + JWT Auth + Excel/PDF Engine"}
                    </p>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {codeHubPlatform === "android"
                    ? "Complete enterprise-grade Android files. Equipped with local AES-256 SQLCipher page encryption, Room index parameters for 100,000+ AWBs, Hilt dependency injections, and direct SQLite triggers."
                    : "Complete, production-ready backend source files. Protected by JWT headers, including transactional database updates, high-throughput CSV/Excel binary stream imports, and multi-dimensional reports."}
                </p>

                {/* File list scroll pane */}
                <div className="space-y-2 mt-2 max-h-[350px] overflow-y-auto pr-1">
                  {codeHubPlatform === "android" ? (
                    ANDROID_PROJECT_FILES.map((file) => (
                      <button
                        key={file.path}
                        onClick={() => setSelectedKotlinFile(file)}
                        className={`w-full text-left p-3 rounded-xl border text-xs flex items-start gap-3 transition-all cursor-pointer ${
                          selectedKotlinFile.path === file.path
                            ? "bg-blue-600/10 border-blue-500 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700"
                        }`}
                      >
                        <div className="mt-0.5">
                          <FileCode className="h-4 w-4 text-blue-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <strong className="block font-mono text-xs text-white truncate">{file.path.split("/").pop()}</strong>
                          <span className="text-[10px] text-slate-500 block truncate mt-0.5">{file.path}</span>
                        </div>
                      </button>
                    ))
                  ) : (
                    BACKEND_PROJECT_FILES.map((file) => (
                      <button
                        key={file.path}
                        onClick={() => setSelectedBackendFile(file)}
                        className={`w-full text-left p-3 rounded-xl border text-xs flex items-start gap-3 transition-all cursor-pointer ${
                          selectedBackendFile.path === file.path
                            ? "bg-blue-600/10 border-blue-500 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700"
                        }`}
                      >
                        <div className="mt-0.5">
                          <FileCode className="h-4 w-4 text-orange-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <strong className="block font-mono text-xs text-white truncate">{file.path.split("/").pop()}</strong>
                          <span className="text-[10px] text-slate-500 block truncate mt-0.5">{file.path}</span>
                        </div>
                      </button>
                    ))
                  )}
                </div>

                {/* Optimization Tips Footer Card */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 text-xs mt-3">
                  <h4 className="font-bold text-orange-400 mb-1 flex items-center gap-1.5">
                    <ShieldAlert className="h-3.5 w-3.5" /> 
                    {codeHubPlatform === "android" ? "Database Performance Note" : "High Availability Optimizations"}
                  </h4>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    {codeHubPlatform === "android"
                      ? "SQLite index parameters allow instant execution under 3 milliseconds on up to 50,000+ bookings directly within standard smartphone hardware caches."
                      : "The MySQL migrations define composite indices for (`branch`, `approval_status`) and (`awb_number`, `customer_name`, `mobile`) to handle queries on over 100,000+ entries seamlessly."}
                  </p>
                </div>
              </div>

              {/* Source Viewer Area (Lg: 8 columns) */}
              <div className="lg:col-span-8 flex flex-col bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden min-h-[600px]">
                
                {/* Source File Info Header */}
                <div className="bg-slate-950 px-5 py-3 border-b border-slate-850 flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <FileCode className="h-4.5 w-4.5 text-blue-400" />
                    <div>
                      <strong className="text-xs text-slate-200 block font-mono">
                        {codeHubPlatform === "android" ? selectedKotlinFile.path : selectedBackendFile.path}
                      </strong>
                      <span className="text-[10px] text-slate-400">
                        {codeHubPlatform === "android" ? selectedKotlinFile.description : selectedBackendFile.description}
                      </span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        const contentToCopy = codeHubPlatform === "android" ? selectedKotlinFile.content : selectedBackendFile.content;
                        navigator.clipboard.writeText(contentToCopy);
                        alert("Source code copied to system clipboard!");
                      }}
                      className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Copy className="h-3.5 w-3.5" /> Copy Code
                    </button>
                    <button
                      onClick={() => {
                        if (codeHubPlatform === "android") {
                          downloadKotlinCodeFile(selectedKotlinFile);
                        } else {
                          const element = document.createElement("a");
                          const fileBlob = new Blob([selectedBackendFile.content], { type: 'text/plain' });
                          element.href = URL.createObjectURL(fileBlob);
                          element.download = selectedBackendFile.path.split("/").pop() || "code.txt";
                          document.body.appendChild(element);
                          element.click();
                          element.remove();
                        }
                      }}
                      className="bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="h-3.5 w-3.5" /> Download File
                    </button>
                  </div>
                </div>

                {/* Styled Code text box with Monospace typing */}
                <div className="flex-1 p-5 overflow-auto font-mono text-xs bg-slate-950 text-slate-300 leading-relaxed whitespace-pre select-text">
                  <code>{codeHubPlatform === "android" ? selectedKotlinFile.content : selectedBackendFile.content}</code>
                </div>

              </div>

            </motion.div>
          )}

          {/* SYSTEM SPECIFICATION SUMMARY */}
          {activeTab === "about" && (
            <motion.div
              key="spec-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-6 lg:p-8 shadow-xl max-w-4xl mx-auto flex flex-col gap-6"
              id="specs-canvas"
            >
              <div className="border-b border-slate-800 pb-4">
                <h2 className="font-display font-extrabold text-2xl text-white">SQLite Encryption & Offline Protocol Spec</h2>
                <p className="text-xs text-slate-400 mt-1">
                  Technical blueprint describing synchronization topology and relational schema indices.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                <div className="space-y-4">
                  <h3 className="font-display font-bold text-base text-blue-400 border-b border-slate-800 pb-1">1. Encryption Pipeline (SQLCipher)</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    The Room Database incorporates SQLite encryption utilizing the <strong>SQLCipher</strong> Android library. Database pages are automatically scrambled using AES-256 bit algorithms. The passphrase is securely calculated on device startup utilizing Android's local KeyStore system, protecting raw bytes if the handset file directories are harvested.
                  </p>
                  
                  <h3 className="font-display font-bold text-base text-blue-400 border-b border-slate-800 pb-1">2. Local Hotspot Synchronization</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Addresses connectivity limitations (Hindi tip context). The Master Admin handset initializes a standard local Wi-Fi Hotspot daemon. Branch handhelds log into this local SSID to request socket access, establishing safe peer-to-peer tunnels. Approved ledger adjustments and new consignments are synced via socket-level streams in seconds.
                  </p>
                </div>

                <div className="space-y-4">
                  <h3 className="font-display font-bold text-base text-orange-400 border-b border-slate-800 pb-1">3. SQLite Query Index Performance</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    To maintain rapid pagination speeds for databases containing <strong>50,000+ AWB consignments</strong>, indices are mapped on AWB identifiers and station branches. This ensures the SQLite query parser immediately references static records under 3 milliseconds, avoiding expensive linear storage scans.
                  </p>

                  <h3 className="font-display font-bold text-base text-orange-400 border-b border-slate-800 pb-1">4. Android Storage Pathing</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Backup actions output plain SQLite structures or standard structured JSON directly to the Android handset's local external files folder (<code className="font-mono text-white bg-slate-950 px-1.5 py-0.5 rounded text-[10px]">Android/data/com.svg.smartapproval/files/backup/</code>). System operators pull or upload files securely to restore historical ledgers on replacement devices.
                  </p>
                </div>

              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-center justify-between gap-4 mt-4">
                <div className="flex items-center gap-3">
                  <FileSpreadsheet className="h-8 w-8 text-green-400" />
                  <div>
                    <h4 className="text-sm font-bold text-white">Full-Stack Logistics System Active</h4>
                    <p className="text-[11px] text-slate-400">Generate local CSV datasets to stress-test these queries directly.</p>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab("simulator")}
                  className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-2 px-4 rounded-xl shadow-lg transition-all cursor-pointer shrink-0"
                >
                  Return to Simulator
                </button>
              </div>

            </motion.div>
          )}

        </AnimatePresence>

      </main>

      {/* POPUP SCANNER: CAMERA QR CODE READER */}
      {showQRScanner && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fade-in" id="qr-scanner-overlay">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl h-[90vh] md:h-[80vh] flex flex-col overflow-hidden shadow-2xl relative"
          >
            <QRScanner
              onScanSuccess={handleQRScanSuccess}
              onClose={() => setShowQRScanner(false)}
              availableAwbs={awbBookings}
            />
          </motion.div>
        </div>
      )}

      {/* POPUP MODAL: REQUEST EXTRA SURCHARGE (BRANCH SIDE) */}
      {showRequestExtraModal && selectedAwb && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in" id="request-modal-overlay">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md flex flex-col gap-4 shadow-2xl"
          >
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="font-display font-extrabold text-base text-white">Request Extra Approval</h3>
              <button onClick={() => setShowRequestExtraModal(false)} className="text-slate-400 hover:text-slate-200">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 text-xs flex flex-col gap-1">
              <span className="text-slate-500">Selected Consignment:</span>
              <strong className="text-white text-sm font-mono">{selectedAwb.awbNumber}</strong>
              <span className="text-slate-400 mt-0.5">Base Billed Cost: ₹{selectedAwb.originalAmount}</span>
            </div>

            <form onSubmit={handleRequestExtraApproval} className="flex flex-col gap-4">
              
              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-slate-300">Surcharge Amount (INR)</label>
                <input
                  type="number"
                  required
                  placeholder="e.g. 500, 1200"
                  value={requestExtraAmount}
                  onChange={(e) => setRequestExtraAmount(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-slate-300">Category Reason</label>
                <select
                  value={requestExtraReason}
                  onChange={(e) => setRequestExtraReason(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="Forklift & Loading Helpers Surcharge">Forklift & Unloading Surcharge</option>
                  <option value="Out of municipal limits / Remote delivery fee">Remote Zone Delivery</option>
                  <option value="Fragile Packaging & Wooden Crating fee">Special Crating</option>
                  <option value="Toll Plaza Surcharge & fuel adjustments">Toll Surcharge</option>
                  <option value="Temporary warehousing storage holding fee">Temporary Storage</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-slate-300">Detailed Surcharge Remarks</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Provide precise operational details for Admin approval review..."
                  value={requestExtraRemarks}
                  onChange={(e) => setRequestExtraRemarks(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <button
                type="submit"
                className="bg-gradient-to-r from-orange-600 to-orange-500 text-white font-bold text-xs py-3 rounded-xl uppercase tracking-wider cursor-pointer"
              >
                Submit Sync Request Block
              </button>
            </form>
          </motion.div>
        </div>
      )}

      {/* POPUP MODAL: ADMIN APPROVE / REJECT DIALOG */}
      {showApprovalDialog && selectedRequestToDecide && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in" id="decision-modal-overlay">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md flex flex-col gap-4 shadow-2xl"
          >
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="font-display font-extrabold text-base text-white">
                {decisionType === "Approve" ? "Approve Extra Funds" : "Reject Extra Surcharge"}
              </h3>
              <button onClick={() => setShowApprovalDialog(false)} className="text-slate-400 hover:text-slate-200">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 text-xs flex flex-col gap-1">
              <div className="flex justify-between">
                <span className="text-slate-500">AWB Number:</span>
                <strong className="text-white font-mono">{selectedRequestToDecide.awbNumber}</strong>
              </div>
              <div className="flex justify-between mt-1">
                <span className="text-slate-500">Requested Amount:</span>
                <span className="text-orange-400 font-bold">₹{selectedRequestToDecide.requestedAmount}</span>
              </div>
              <div className="flex justify-between mt-1 border-t border-slate-800/40 pt-1">
                <span className="text-slate-500">Reason category:</span>
                <span className="text-slate-300 font-medium">{selectedRequestToDecide.reason}</span>
              </div>
              <p className="text-[11px] text-slate-400 italic mt-1 bg-slate-900 p-2 rounded border border-slate-850">
                "{selectedRequestToDecide.remarks}"
              </p>
            </div>

            <form onSubmit={handleAdminDecisionSubmit} className="flex flex-col gap-4">
              
              {decisionType === "Approve" && (
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-slate-300">Approved Surcharge (INR)</label>
                  <input
                    type="number"
                    required
                    value={decisionApprovedAmount}
                    onChange={(e) => setDecisionApprovedAmount(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm text-white focus:outline-none"
                  />
                </div>
              )}

              <div className="flex flex-col gap-1">
                <label className="text-xs font-bold text-slate-300">Admin Operational Remark</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Approved heavy machinery lift / Surcharges unjustified"
                  value={decisionAdminRemark}
                  onChange={(e) => setDecisionAdminRemark(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowApprovalDialog(false)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold py-2.5 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`flex-1 text-white text-xs font-bold py-2.5 rounded-xl cursor-pointer ${
                    decisionType === "Approve" ? "bg-green-600 hover:bg-green-500" : "bg-red-600 hover:bg-red-500"
                  }`}
                >
                  Confirm {decisionType}
                </button>
              </div>

            </form>
          </motion.div>
        </div>
      )}

      {/* Footer Branding line */}
      <footer className="bg-slate-950 border-t border-slate-900 py-4 text-center text-[11px] text-slate-500 flex flex-col items-center gap-1">
        <span>SVG SMART LOGISTICS GROUP © 2026. ALL RIGHTS RESERVED.</span>
        <span>Secure Local Sandboxing Sandbox. No Cloud Telemetry active.</span>
      </footer>

    </div>
  );
}
