import { jsPDF } from "jspdf";
import * as XLSX from "xlsx";
import { AWB } from "../types";

export interface ReportSummary {
  approvedAmount: number;
  rejectedAmount: number;
  pendingAmount: number;
  totalEarnings: number;
  totalCNCount: number;
}

export function calculateReportSummary(filteredAwbs: AWB[]): ReportSummary {
  let approvedAmount = 0;
  let rejectedAmount = 0;
  let pendingAmount = 0;
  let totalEarnings = 0;

  filteredAwbs.forEach((awb) => {
    // Earnings = Actual Amount + Additional Surcharges (only if approved)
    // Actually totalAmount includes additionalApprovedAmount if approved.
    totalEarnings += awb.totalAmount;
    
    // Surcharges tracking
    if (awb.approvalStatus === "Approved") {
      approvedAmount += awb.additionalAmount;
    } else if (awb.approvalStatus === "Rejected") {
      rejectedAmount += awb.additionalAmount; // Or we can trace requested amount if available
    } else if (awb.approvalStatus === "Pending") {
      pendingAmount += awb.additionalAmount;
    }
  });

  return {
    approvedAmount,
    rejectedAmount,
    pendingAmount,
    totalEarnings,
    totalCNCount: filteredAwbs.length
  };
}

export function generatePDFReport(filteredAwbs: AWB[], title: string, subtitle: string) {
  const doc = new jsPDF();
  const summary = calculateReportSummary(filteredAwbs);
  
  // Header Design
  doc.setFillColor(30, 64, 175); // Dark blue header background
  doc.rect(0, 0, 210, 40, "F");
  
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.text("SVG SMART EXTRA APPROVAL SYSTEM", 14, 18);
  
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(226, 232, 240);
  doc.text(`${title} - ${subtitle}`, 14, 26);
  doc.text(`Export Timestamp: ${new Date().toLocaleString()} | Operational Mode: Multi-Branch SQLite Cache`, 14, 32);
  
  // Reset text color
  doc.setTextColor(15, 23, 42);
  
  // Summary Cards Table
  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.text("Financial Summary Statistics", 14, 52);
  
  doc.setFillColor(248, 250, 252);
  doc.rect(14, 56, 182, 28, "F");
  doc.setDrawColor(226, 232, 240);
  doc.rect(14, 56, 182, 28, "S");
  
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(`Total Shipments (CN):`, 18, 62);
  doc.text(`Total Earned Freight:`, 18, 70);
  doc.text(`Pending Extra Requested:`, 18, 78);
  
  doc.text(`Approved Extra Surcharges:`, 110, 62);
  doc.text(`Rejected Extra Surcharges:`, 110, 70);
  
  doc.setFont("helvetica", "bold");
  doc.text(String(summary.totalCNCount), 55, 62);
  doc.text(`INR ${summary.totalEarnings.toLocaleString()}`, 55, 70);
  doc.text(`INR ${summary.pendingAmount.toLocaleString()}`, 55, 78);
  
  doc.setTextColor(22, 163, 74); // Green
  doc.text(`INR ${summary.approvedAmount.toLocaleString()}`, 160, 62);
  doc.setTextColor(220, 38, 38); // Red
  doc.text(`INR ${summary.rejectedAmount.toLocaleString()}`, 160, 70);
  doc.setTextColor(15, 23, 42); // Reset
  
  // Table columns
  let currentY = 96;
  doc.setFontSize(12);
  doc.text("Consignment Ledger Listings", 14, 91);
  
  doc.setFillColor(30, 64, 175); // Blue table header
  doc.rect(14, currentY, 182, 8, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  
  doc.text("Booking Date", 16, currentY + 5.5);
  doc.text("AWB Number", 38, currentY + 5.5);
  doc.text("Customer", 65, currentY + 5.5);
  doc.text("Branch", 112, currentY + 5.5);
  doc.text("Status", 132, currentY + 5.5);
  doc.text("Freight (INR)", 150, currentY + 5.5);
  doc.text("Total (INR)", 175, currentY + 5.5);
  
  doc.setTextColor(15, 23, 42);
  doc.setFont("helvetica", "normal");
  
  const itemsToRender = filteredAwbs.slice(0, 50); // limit to 50 for safety in preview pdf
  itemsToRender.forEach((awb) => {
    currentY += 8;
    if (currentY > 275) {
      doc.addPage();
      currentY = 20;
      
      // Draw header on new page
      doc.setFillColor(30, 64, 175);
      doc.rect(14, currentY, 182, 8, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.text("Booking Date", 16, currentY + 5.5);
      doc.text("AWB Number", 38, currentY + 5.5);
      doc.text("Customer", 65, currentY + 5.5);
      doc.text("Branch", 112, currentY + 5.5);
      doc.text("Status", 132, currentY + 5.5);
      doc.text("Freight (INR)", 150, currentY + 5.5);
      doc.text("Total (INR)", 175, currentY + 5.5);
      
      doc.setTextColor(15, 23, 42);
      doc.setFont("helvetica", "normal");
      currentY += 8;
    }
    
    // Draw alternate row colors
    doc.setFillColor(248, 250, 252);
    doc.rect(14, currentY - 1, 182, 8, "F");
    
    doc.text(awb.bookingDate, 16, currentY + 5);
    doc.text(awb.awbNumber, 38, currentY + 5);
    
    // Truncate customer name if long
    let cust = awb.customerName;
    if (cust.length > 25) cust = cust.substring(0, 22) + "...";
    doc.text(cust, 65, currentY + 5);
    
    doc.text(awb.branch, 112, currentY + 5);
    doc.text(awb.approvalStatus === "None" ? "Standard" : awb.approvalStatus, 132, currentY + 5);
    doc.text(String(awb.actualAmount), 150, currentY + 5);
    doc.text(String(awb.totalAmount), 175, currentY + 5);
  });
  
  if (filteredAwbs.length > 50) {
    currentY += 8;
    doc.setFont("helvetica", "italic");
    doc.text(`* Note: Report truncated. Showing first 50 of ${filteredAwbs.length} matching rows in mobile storage views.`, 14, currentY + 5);
  }
  
  doc.save(`SVG_Logistics_Report_${title.replace(/\s+/g, "_")}.pdf`);
}

export function generateExcelReport(filteredAwbs: AWB[], title: string) {
  const rows = filteredAwbs.map((awb) => ({
    "Branch": awb.branch,
    "Booking Date": awb.bookingDate,
    "AWB Number": awb.awbNumber,
    "Customer Name": awb.customerName,
    "Customer Address": awb.customerAddress,
    "Delivery Branch": awb.deliveryBranch,
    "ODA / Local": awb.odaOrLocal,
    "Box Quantity": awb.boxQuantity,
    "Weight (kg)": awb.weight,
    "Actual Amount (INR)": awb.actualAmount,
    "Additional Amount (INR)": awb.additionalAmount,
    "Total Amount (INR)": awb.totalAmount,
    "Approval Status": awb.approvalStatus,
    "Admin Remark": awb.adminRemark
  }));
  
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Logistics Report");
  
  XLSX.writeFile(workbook, `SVG_Logistics_Ledger_${title.replace(/\s+/g, "_")}.xlsx`);
}
