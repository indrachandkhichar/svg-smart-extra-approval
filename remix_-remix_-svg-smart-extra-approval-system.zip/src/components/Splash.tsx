import React, { useEffect, useState } from "react";
import { motion } from "motion/react";
import { Sparkles, Truck, ShieldCheck, Cpu } from "lucide-react";

interface SplashProps {
  onComplete: () => void;
  isDarkMode: boolean;
}

export const Splash: React.FC<SplashProps> = ({ onComplete, isDarkMode }) => {
  const [loadingStep, setLoadingStep] = useState(0);

  useEffect(() => {
    const timer1 = setTimeout(() => setLoadingStep(1), 800);
    const timer2 = setTimeout(() => setLoadingStep(2), 1600);
    const timer3 = setTimeout(() => setLoadingStep(3), 2400);
    const timer4 = setTimeout(() => onComplete(), 3200);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [onComplete]);

  const steps = [
    "Initializing secure offline vault...",
    "Loading Room SQLite database...",
    "Hashing JWT signature engines...",
    "SVG Smart Logistics Online!"
  ];

  return (
    <div className={`fixed inset-0 z-[100] flex flex-col items-center justify-center p-6 ${
      isDarkMode ? "bg-slate-950 text-white" : "bg-slate-50 text-slate-900"
    }`}>
      <div className="max-w-md w-full flex flex-col items-center text-center space-y-8">
        
        {/* Animated Corporate SVG Logo Container */}
        <motion.div
          initial={{ scale: 0.5, opacity: 0, rotate: -45 }}
          animate={{ scale: [1, 1.1, 1], opacity: 1, rotate: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative"
        >
          {/* Logo backdrop glow */}
          <div className="absolute -inset-4 rounded-3xl bg-gradient-to-tr from-blue-600 to-orange-500 opacity-20 blur-xl animate-pulse" />
          
          <div className="h-24 w-24 rounded-3xl bg-gradient-to-tr from-blue-600 to-orange-500 p-0.5 shadow-2xl relative z-10 flex items-center justify-center">
            <div className={`h-full w-full rounded-[22px] flex flex-col items-center justify-center relative overflow-hidden ${
              isDarkMode ? "bg-slate-950" : "bg-slate-50"
            }`}>
              <div className="absolute -right-2 -bottom-2 h-12 w-12 rounded-full bg-orange-500/10" />
              <div className="absolute -left-2 -top-2 h-12 w-12 rounded-full bg-blue-500/10" />
              
              <Truck className="h-10 w-10 text-blue-500 animate-bounce" />
              <div className="text-[10px] font-extrabold uppercase tracking-widest text-orange-500 font-display mt-1">
                SVG SMART
              </div>
            </div>
          </div>
        </motion.div>

        {/* System Name with custom display typography */}
        <div className="space-y-2">
          <motion.h1
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.6 }}
            className="text-3xl font-display font-black tracking-tight"
          >
            <span className="bg-gradient-to-r from-blue-500 to-blue-600 bg-clip-text text-transparent">SVG SMART</span>{" "}
            <span className="bg-gradient-to-r from-orange-500 to-orange-600 bg-clip-text text-transparent">LOGISTICS</span>
          </motion.h1>
          <motion.p
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className={`text-xs font-semibold uppercase tracking-widest ${
              isDarkMode ? "text-slate-400" : "text-slate-500"
            }`}
          >
            Extra Approval Management System
          </motion.p>
        </div>

        {/* Animated Loading Bar with Steps */}
        <div className="w-64 space-y-3">
          <div className={`h-1.5 w-full rounded-full overflow-hidden relative ${
            isDarkMode ? "bg-slate-800" : "bg-slate-200"
          }`}>
            <motion.div
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ duration: 3.2, ease: "easeInOut" }}
              className="h-full bg-gradient-to-r from-blue-600 to-orange-500 rounded-full"
            />
          </div>
          
          <div className="h-5 flex items-center justify-center">
            <motion.p
              key={loadingStep}
              initial={{ y: 5, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -5, opacity: 0 }}
              className="text-[11px] font-mono text-slate-500 font-semibold"
            >
              {steps[loadingStep]}
            </motion.p>
          </div>
        </div>

        {/* Technology Badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="flex flex-wrap justify-center gap-2 pt-6 border-t border-slate-800/20 max-w-sm"
        >
          {["Kotlin", "Compose", "Room Cipher", "Laravel PHP", "MySQL", "JWT Auth"].map((tech) => (
            <span key={tech} className={`px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold ${
              isDarkMode ? "bg-slate-900 text-slate-400 border border-slate-800" : "bg-slate-100 text-slate-600 border border-slate-200"
            }`}>
              {tech}
            </span>
          ))}
        </motion.div>

        {/* Trust Badges */}
        <div className="flex items-center gap-4 text-slate-500 text-[10px] font-semibold pt-4">
          <div className="flex items-center gap-1">
            <ShieldCheck className="h-3.5 w-3.5 text-blue-500" />
            <span>Secure SQLCipher</span>
          </div>
          <div className="h-3 w-[1px] bg-slate-800/20" />
          <div className="flex items-center gap-1">
            <Cpu className="h-3.5 w-3.5 text-orange-500" />
            <span>Dual Role Sandboxed</span>
          </div>
        </div>

      </div>
    </div>
  );
};
