import * as XLSX from "xlsx";

export const EXCEL_COLUMNS = [
  "Branch",
  "Booking Date",
  "AWB Number",
  "Customer Name",
  "Customer Address",
  "Delivery Branch",
  "ODA / Local",
  "Box Quantity",
  "Weight",
  "Actual Amount",
  "Additional Amount",
  "Total Amount",
  "Approval Status",
  "Admin Remark"
];

export function downloadSampleExcel() {
  const sampleData = [
    {
      "Branch": "Chennai",
      "Booking Date": "2026-07-16",
      "AWB Number": "AWB1002350",
      "Customer Name": "Acme Industrial Tools",
      "Customer Address": "No. 12, Industrial Main Road, Sector 3, Chennai",
      "Delivery Branch": "Bangalore",
      "ODA / Local": "Local",
      "Box Quantity": 5,
      "Weight": 12.5,
      "Actual Amount": 1850,
      "Additional Amount": 0,
      "Total Amount": 1850,
      "Approval Status": "None",
      "Admin Remark": ""
    },
    {
      "Branch": "Siliguri",
      "Booking Date": "2026-07-16",
      "AWB Number": "AWB1002351",
      "Customer Name": "Himalayan Organic Tea Ltd",
      "Customer Address": "Sevoke Road Bypass, Siliguri, WB",
      "Delivery Branch": "Surat",
      "ODA / Local": "ODA",
      "Box Quantity": 10,
      "Weight": 35.0,
      "Actual Amount": 4500,
      "Additional Amount": 1200,
      "Total Amount": 5700,
      "Approval Status": "Approved",
      "Admin Remark": "Approved ODA special transit handling charge"
    }
  ];

  const worksheet = XLSX.utils.json_to_sheet(sampleData, { header: EXCEL_COLUMNS });
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Sample Logistics Template");

  // Write and trigger download
  XLSX.writeFile(workbook, "SVG_Smart_Logistics_Sample_Template.xlsx");
}
