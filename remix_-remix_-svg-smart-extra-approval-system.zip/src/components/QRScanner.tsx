import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Camera,
  X,
  RefreshCw,
  AlertCircle,
  Check,
  Volume2,
  VolumeX,
  Sparkles,
  Search,
  Upload,
  Minimize,
  Smartphone,
  CheckCircle,
  HelpCircle
} from "lucide-react";
import jsQR from "jsqr";
import { AWB } from "../types";

interface QRScannerProps {
  onScanSuccess: (awbNumber: string) => void;
  onClose: () => void;
  availableAwbs: AWB[];
}

export function QRScanner({ onScanSuccess, onClose, availableAwbs }: QRScannerProps) {
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>("");
  const [isScanning, setIsScanning] = useState<boolean>(true);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [scanFeedback, setScanFeedback] = useState<{ success: boolean; text: string } | null>(null);
  const [simulatedAwb, setSimulatedAwb] = useState<string>("");

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const requestRef = useRef<number | null>(null);

  // Initialize simulated AWB dropdown option
  useEffect(() => {
    if (availableAwbs.length > 0) {
      setSimulatedAwb(availableAwbs[0].awbNumber);
    }
  }, [availableAwbs]);

  // Audio success beep using standard Web Audio API
  const playBeep = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(1000, audioCtx.currentTime); // high scan beep
      gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);

      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.12); // 120ms duration
    } catch (e) {
      console.warn("Audio Context scan beep failed:", e);
    }
  };

  // Enumerate video devices and check permission
  useEffect(() => {
    const initDevices = async () => {
      try {
        // Force checking permissions by initiating a lightweight call
        const initialStream = await navigator.mediaDevices.getUserMedia({ video: true });
        initialStream.getTracks().forEach((track) => track.stop()); // close immediately

        setHasCameraPermission(true);

        const mediaDevices = await navigator.mediaDevices.enumerateDevices();
        const videoDevices = mediaDevices.filter((device) => device.kind === "videoinput");
        setDevices(videoDevices);

        if (videoDevices.length > 0) {
          // Default to the back camera (environment) if available, otherwise first camera
          const backCam = videoDevices.find(
            (d) =>
              d.label.toLowerCase().includes("back") ||
              d.label.toLowerCase().includes("environment") ||
              d.label.toLowerCase().includes("rear")
          );
          setSelectedDeviceId(backCam ? backCam.deviceId : videoDevices[0].deviceId);
        }
      } catch (err: any) {
        console.error("Camera access error:", err);
        setHasCameraPermission(false);
        setErrorMessage(
          err.message || "Camera access was denied. Ensure your browser allows camera access."
        );
      }
    };

    initDevices();

    return () => {
      stopCamera();
    };
  }, []);

  // Control camera stream based on selectedDeviceId and isScanning
  useEffect(() => {
    if (isScanning && selectedDeviceId) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [selectedDeviceId, isScanning]);

  const stopCamera = () => {
    if (requestRef.current) {
      cancelAnimationFrame(requestRef.current);
      requestRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  const startCamera = async () => {
    stopCamera();
    try {
      const constraints = {
        video: {
          deviceId: selectedDeviceId ? { exact: selectedDeviceId } : undefined,
          facingMode: selectedDeviceId ? undefined : "environment",
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute("playsinline", "true"); // required for iOS Safari
        videoRef.current.play();

        // Start processing frames once the video has loaded metadata
        videoRef.current.onloadedmetadata = () => {
          requestRef.current = requestAnimationFrame(scanFrame);
        };
      }
    } catch (err: any) {
      console.error("Error starting camera device:", err);
      setErrorMessage("Could not open the camera. It may be in use by another app.");
    }
  };

  // Perform frame scanning analysis
  const scanFrame = () => {
    if (!videoRef.current || !canvasRef.current || !isScanning) {
      requestRef.current = requestAnimationFrame(scanFrame);
      return;
    }

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d", { willReadFrequently: true });

    if (context && video.readyState === video.HAVE_CURRENT_DATA) {
      const width = video.videoWidth;
      const height = video.videoHeight;

      // Adjust internal canvas sizing
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }

      // Draw standard camera frame onto offscreen canvas
      context.drawImage(video, 0, 0, width, height);

      // Extract image pixels to run QR decoder
      try {
        const imageData = context.getImageData(0, 0, width, height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: "dontInvert",
        });

        if (code) {
          // Successfully read a QR code!
          const resultText = code.data.trim();
          
          // Draw bright bounding box around detected code on our visual preview canvas
          drawBoundingBox(context, code.location);

          // Check if parsed content corresponds to any actual system consignment
          const foundAwb = availableAwbs.find(
            (awb) => awb.awbNumber.toLowerCase() === resultText.toLowerCase()
          );

          if (foundAwb) {
            handleSuccessfulScan(foundAwb.awbNumber);
            return; // stop scanning loop
          } else {
            // Decoded a QR code, but it doesn't match our database
            setScanFeedback({
              success: false,
              text: `Scanned: "${resultText.slice(0, 16)}" (AWB not in offline local list)`,
            });
          }
        }
      } catch (e) {
        // Silently capture context read issues during active tab switching
      }
    }

    requestRef.current = requestAnimationFrame(scanFrame);
  };

  const drawBoundingBox = (
    context: CanvasRenderingContext2D,
    location: {
      topLeftCorner: { x: number; y: number };
      topRightCorner: { x: number; y: number };
      bottomRightCorner: { x: number; y: number };
      bottomLeftCorner: { x: number; y: number };
    }
  ) => {
    context.beginPath();
    context.moveTo(location.topLeftCorner.x, location.topLeftCorner.y);
    context.lineTo(location.topRightCorner.x, location.topRightCorner.y);
    context.lineTo(location.bottomRightCorner.x, location.bottomRightCorner.y);
    context.lineTo(location.bottomLeftCorner.x, location.bottomLeftCorner.y);
    context.closePath();
    context.lineWidth = 6;
    context.strokeStyle = "#22C55E"; // Success green glow
    context.stroke();
  };

  const handleSuccessfulScan = (awbNumber: string) => {
    setIsScanning(false);
    playBeep();
    setScanFeedback({
      success: true,
      text: `MATCHED: ${awbNumber} successfully!`,
    });

    // Provide visual reward before triggering main state changes
    setTimeout(() => {
      onScanSuccess(awbNumber);
    }, 1200);
  };

  // Drag & drop or local file selection decoding fallback
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const reader = new FileReader();

    reader.onload = (evt) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          try {
            const imgData = ctx.getImageData(0, 0, img.width, img.height);
            const decoded = jsQR(imgData.data, imgData.width, imgData.height);
            if (decoded) {
              const cleanedText = decoded.data.trim();
              const found = availableAwbs.find(
                (awb) => awb.awbNumber.toLowerCase() === cleanedText.toLowerCase()
              );
              if (found) {
                handleSuccessfulScan(found.awbNumber);
              } else {
                setScanFeedback({
                  success: false,
                  text: `Found QR: "${cleanedText.slice(0, 15)}" but it does not match active AWBs.`,
                });
              }
            } else {
              alert("No valid QR code could be decoded from this image file.");
            }
          } catch (err) {
            alert("Could not extract image bytes. Ensure file is a standard web image.");
          }
        }
      };
      img.src = evt.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const triggerSimulatedScan = () => {
    if (!simulatedAwb) return;
    setIsScanning(false);
    playBeep();
    setScanFeedback({
      success: true,
      text: `SIMULATING: Reading label for AWB ${simulatedAwb}...`,
    });

    setTimeout(() => {
      onScanSuccess(simulatedAwb);
    }, 1000);
  };

  return (
    <div className="absolute inset-0 bg-slate-950/95 z-50 flex flex-col p-4 animate-fade-in" id="qr-scanner-window">
      
      {/* Header Panel */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-orange-600/20 text-orange-400 flex items-center justify-center animate-pulse">
            <Camera className="h-4.5 w-4.5" />
          </div>
          <div>
            <h3 className="font-display font-extrabold text-sm text-white flex items-center gap-1.5">
              AWB Label QR Scanner
              <span className="text-[9px] font-mono bg-blue-600 text-white px-1.5 py-0.5 rounded uppercase font-bold tracking-wider">
                Native JS
              </span>
            </h3>
            <p className="text-[10px] text-slate-400">Position AWB barcode/QR code within the frame</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Sound toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all cursor-pointer`}
            title={soundEnabled ? "Mute beep" : "Enable beep"}
          >
            {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </button>
          
          {/* Close Scanner */}
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-all cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Main Scanner Stage */}
      <div className="flex-1 flex flex-col lg:flex-row gap-4 items-stretch min-h-0">
        
        {/* Visual Camera Feed Display Panel */}
        <div className="flex-1 relative bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col justify-center items-center">
          
          {hasCameraPermission === true && isScanning && (
            <>
              {/* Offscreen scanning canvas is rendered here implicitly or overlaid */}
              <canvas ref={canvasRef} className="absolute inset-0 w-full h-full object-cover scale-x-[-1] opacity-30 pointer-events-none" />
              
              {/* Video Element for user feed */}
              <video
                ref={videoRef}
                className="w-full h-full object-cover rounded-2xl scale-x-[-1]"
                muted
                playsInline
              />

              {/* Laser Scanning Line Overlay */}
              <div className="absolute inset-x-8 h-0.5 bg-gradient-to-r from-transparent via-orange-500 to-transparent top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4/5 animate-[bounce_2s_infinite] shadow-[0_0_15px_#EA580C] z-10 pointer-events-none" />

              {/* Futuristic Crosshairs */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                <div className="w-64 h-64 border-2 border-orange-500/30 rounded-3xl relative flex items-center justify-center">
                  
                  {/* Glowing corners */}
                  <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-orange-500 -mt-1 -ml-1 rounded-tl-xl" />
                  <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-orange-500 -mt-1 -mr-1 rounded-tr-xl" />
                  <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-orange-500 -mb-1 -ml-1 rounded-bl-xl" />
                  <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-orange-500 -mb-1 -mr-1 rounded-br-xl" />

                  <span className="text-[10px] font-mono text-orange-400 bg-slate-950/80 px-2.5 py-1 rounded-full border border-orange-500/20 uppercase tracking-widest animate-pulse">
                    Align QR Label
                  </span>
                </div>
              </div>

              {/* Camera Swapper */}
              {devices.length > 1 && (
                <div className="absolute bottom-4 left-4 right-4 z-20 flex justify-center">
                  <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-1.5 flex gap-1.5">
                    {devices.map((device, idx) => (
                      <button
                        key={device.deviceId}
                        onClick={() => setSelectedDeviceId(device.deviceId)}
                        className={`px-3 py-1 text-[10px] font-bold rounded-lg uppercase tracking-wider transition-all cursor-pointer ${
                          selectedDeviceId === device.deviceId
                            ? "bg-orange-600 text-white"
                            : "text-slate-400 hover:text-white"
                        }`}
                      >
                        Cam {idx + 1}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}

          {/* Fallback & Waiting Graphics */}
          {hasCameraPermission === null && (
            <div className="text-center p-6 flex flex-col items-center justify-center gap-3">
              <RefreshCw className="h-8 w-8 text-slate-500 animate-spin" />
              <p className="text-xs text-slate-400 font-mono">Initializing camera feed...</p>
            </div>
          )}

          {hasCameraPermission === false && (
            <div className="text-center p-6 flex flex-col items-center justify-center gap-3 max-w-sm">
              <AlertCircle className="h-10 w-10 text-red-500" />
              <h4 className="font-bold text-sm text-white">Camera Access Blocked</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                We couldn't boot the camera due to browser/iframe rules. Do not worry! Use the
                <strong> Interactive Simulator</strong> panel on the right or upload an AWB QR file.
              </p>
              
              <label className="mt-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 text-slate-200 text-xs font-bold py-2.5 px-4 rounded-xl cursor-pointer flex items-center gap-2 transition-all">
                <Upload className="h-3.5 w-3.5" /> Upload AWB QR Image
                <input
                  type="file"
                  onChange={handleImageUpload}
                  accept="image/*"
                  className="hidden"
                />
              </label>
            </div>
          )}

          {/* Scanning Result Banners */}
          <AnimatePresence>
            {scanFeedback && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className={`absolute inset-x-4 top-4 rounded-xl p-3 border z-30 flex items-center gap-2 shadow-xl ${
                  scanFeedback.success
                    ? "bg-green-500/10 border-green-500/30 text-green-400"
                    : "bg-orange-500/10 border-orange-500/30 text-orange-400"
                }`}
              >
                {scanFeedback.success ? (
                  <CheckCircle className="h-5 w-5 shrink-0 animate-bounce" />
                ) : (
                  <AlertCircle className="h-5 w-5 shrink-0" />
                )}
                <span className="text-xs font-mono font-bold">{scanFeedback.text}</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Sidebar: Simulated Scanner & Local DB Tester */}
        <div className="w-full lg:w-80 bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col gap-4">
          <div>
            <h4 className="font-display font-extrabold text-xs text-slate-300 uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-orange-400" />
              Scanner Simulator
            </h4>
            <p className="text-[10px] text-slate-400 leading-normal">
              For immediate testing or within secure iframe sandboxes where hardware cameras may be unavailable, select any active AWB code to trigger a simulated scan.
            </p>
          </div>

          <div className="bg-slate-950 border border-slate-850 rounded-xl p-3 flex flex-col gap-3">
            <div className="flex flex-col gap-1 text-left">
              <label className="text-[9px] uppercase font-bold tracking-wider text-slate-400">Select AWB to Scan</label>
              <select
                value={simulatedAwb}
                onChange={(e) => setSimulatedAwb(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white outline-none font-mono focus:ring-1 focus:ring-orange-600"
              >
                {availableAwbs.length === 0 ? (
                  <option value="">No Active AWBs</option>
                ) : (
                  availableAwbs.map((awb) => (
                    <option key={awb.awbNumber} value={awb.awbNumber}>
                      {awb.awbNumber} ({awb.customerName.slice(0, 15)}...)
                    </option>
                  ))
                )}
              </select>
            </div>

            <button
              onClick={triggerSimulatedScan}
              disabled={availableAwbs.length === 0}
              className="w-full bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 disabled:opacity-50 text-white font-bold text-xs py-2.5 rounded-lg transition-all flex items-center justify-center gap-1.5 shadow-md shadow-orange-600/10 cursor-pointer"
            >
              <Smartphone className="h-3.5 w-3.5" /> Trigger Simulated Scan
            </button>
          </div>

          <div className="border-t border-slate-800 pt-3 flex-1 flex flex-col justify-end">
            <div className="bg-slate-950/60 border border-slate-800/50 rounded-xl p-3 text-left">
              <span className="block text-[9px] text-blue-400 font-extrabold uppercase tracking-wider mb-1 flex items-center gap-1">
                <HelpCircle className="h-3 w-3" /> Quick Tip:
              </span>
              <p className="text-[10px] text-slate-400 leading-relaxed">
                Point your smartphone camera at the computer screen! You can display the QR code generated in the active AWB detail panel and scan it in real-time.
              </p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
