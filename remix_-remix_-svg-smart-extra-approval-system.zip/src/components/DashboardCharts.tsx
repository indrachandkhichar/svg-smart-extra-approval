import React from "react";
import { AWB } from "../types";

interface ChartsProps {
  bookings: AWB[];
  isDarkMode: boolean;
}

export const DashboardCharts: React.FC<ChartsProps> = ({ bookings, isDarkMode }) => {
  // Aggregate data for Daily Earnings (Last 7 days)
  const dailyData = React.useMemo(() => {
    const map: Record<string, number> = {};
    // Let's seed last 7 days including today
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split("T")[0];
      map[dateStr] = 0;
    }

    bookings.forEach((b) => {
      if (map[b.bookingDate] !== undefined) {
        map[b.bookingDate] += b.totalAmount;
      }
    });

    return Object.entries(map).map(([date, amount]) => {
      // Shorten date format e.g. "16 Jul"
      const parts = date.split("-");
      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const day = parseInt(parts[2]);
      const monthIdx = parseInt(parts[1]) - 1;
      const formatted = `${day} ${months[monthIdx]}`;
      return { label: formatted, value: amount };
    });
  }, [bookings]);

  // Aggregate data for Weekly Earnings (Last 4 weeks)
  const weeklyData = React.useMemo(() => {
    // We can simulate weeks or divide bookings into weeks
    const weeks = [
      { label: "Week 1", value: 0 },
      { label: "Week 2", value: 0 },
      { label: "Week 3", value: 0 },
      { label: "Week 4", value: 0 },
    ];

    bookings.forEach((b) => {
      const date = new Date(b.bookingDate);
      const day = date.getDate();
      if (day <= 7) weeks[0].value += b.totalAmount;
      else if (day <= 14) weeks[1].value += b.totalAmount;
      else if (day <= 21) weeks[2].value += b.totalAmount;
      else weeks[3].value += b.totalAmount;
    });

    return weeks;
  }, [bookings]);

  // Aggregate data for Monthly Earnings (Last 6 months)
  const monthlyData = React.useMemo(() => {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const currentMonthIdx = new Date().getMonth();
    const map: Record<string, number> = {};

    for (let i = 5; i >= 0; i--) {
      const idx = (currentMonthIdx - i + 12) % 12;
      map[months[idx]] = 0;
    }

    bookings.forEach((b) => {
      const date = new Date(b.bookingDate);
      const mName = months[date.getMonth()];
      if (map[mName] !== undefined) {
        map[mName] += b.totalAmount;
      }
    });

    return Object.entries(map).map(([label, value]) => ({ label, value }));
  }, [bookings]);

  // Aggregate Branch Performance (Total amount per Branch)
  const branchData = React.useMemo(() => {
    const map: Record<string, number> = {};
    bookings.forEach((b) => {
      map[b.branch] = (map[b.branch] || 0) + b.totalAmount;
    });

    return Object.entries(map)
      .map(([label, value]) => ({ label, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 4); // Top 4 branches
  }, [bookings]);

  const maxDaily = Math.max(...dailyData.map((d) => d.value), 1);
  const maxWeekly = Math.max(...weeklyData.map((d) => d.value), 1);
  const maxMonthly = Math.max(...monthlyData.map((d) => d.value), 1);
  const maxBranch = Math.max(...branchData.map((d) => d.value), 1);

  return (
    <div className="space-y-4">
      {/* Chart 1: Daily Earnings & Branch Performance Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Daily Earnings Bar Chart */}
        <div className={`p-3 rounded-2xl border ${isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200"} shadow-sm`}>
          <div className="flex justify-between items-center mb-2">
            <h4 className={`text-[11px] font-bold uppercase tracking-wider ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Daily Earnings (7-Day)</h4>
            <span className="text-[10px] font-mono text-blue-500 font-bold">₹{dailyData.reduce((s, x) => s + x.value, 0).toLocaleString()} Total</span>
          </div>
          <div className="h-32 flex items-end justify-between gap-1 pt-3">
            {dailyData.map((item, idx) => {
              const pct = (item.value / maxDaily) * 100;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center h-full group relative">
                  <div className="text-[9px] text-blue-500 font-mono font-bold opacity-0 group-hover:opacity-100 absolute -top-3 bg-slate-950 px-1 py-0.5 rounded transition-opacity">
                    ₹{item.value}
                  </div>
                  <div className="w-full flex-1 flex items-end">
                    <div
                      style={{ height: `${Math.max(pct, 5)}%` }}
                      className="w-full rounded-t-sm bg-gradient-to-t from-blue-600 to-blue-400 hover:from-blue-500 hover:to-blue-300 transition-all cursor-pointer shadow-sm"
                    />
                  </div>
                  <span className={`text-[8px] mt-1.5 font-medium truncate w-full text-center ${isDarkMode ? "text-slate-500" : "text-slate-400"}`}>
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Branch Performance Horizontal Chart */}
        <div className={`p-3 rounded-2xl border ${isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200"} shadow-sm`}>
          <div className="flex justify-between items-center mb-2">
            <h4 className={`text-[11px] font-bold uppercase tracking-wider ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Branch performance</h4>
            <span className="text-[10px] font-mono text-orange-500 font-bold">₹{branchData.reduce((s, x) => s + x.value, 0).toLocaleString()}</span>
          </div>
          <div className="space-y-2 pt-1.5">
            {branchData.length === 0 ? (
              <div className="text-center py-6 text-[10px] text-slate-500">No Branch performance data found</div>
            ) : (
              branchData.map((item, idx) => {
                const pct = (item.value / maxBranch) * 100;
                return (
                  <div key={idx} className="space-y-0.5">
                    <div className="flex justify-between text-[10px]">
                      <span className={`font-semibold ${isDarkMode ? "text-slate-300" : "text-slate-700"}`}>{item.label}</span>
                      <span className="font-mono font-bold text-orange-500">₹{item.value.toLocaleString()}</span>
                    </div>
                    <div className={`h-2 w-full rounded-full overflow-hidden ${isDarkMode ? "bg-slate-850" : "bg-slate-100"}`}>
                      <div
                        style={{ width: `${pct}%` }}
                        className="h-full rounded-full bg-gradient-to-r from-orange-500 to-amber-400"
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Chart 2: Weekly & Monthly Earnings Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* Weekly Earnings Line Chart style */}
        <div className={`p-3 rounded-2xl border ${isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200"} shadow-sm`}>
          <div className="flex justify-between items-center mb-2">
            <h4 className={`text-[11px] font-bold uppercase tracking-wider ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Weekly Earnings (This Month)</h4>
            <span className="text-[10px] font-mono text-indigo-500 font-bold">₹{weeklyData.reduce((s, x) => s + x.value, 0).toLocaleString()}</span>
          </div>
          <div className="h-28 flex items-end justify-between gap-1 pt-3">
            {weeklyData.map((item, idx) => {
              const pct = (item.value / maxWeekly) * 100;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center h-full relative group">
                  <div className="text-[9px] text-indigo-500 font-mono font-bold opacity-0 group-hover:opacity-100 absolute -top-3 bg-slate-950 px-1 py-0.5 rounded transition-opacity">
                    ₹{item.value}
                  </div>
                  <div className="w-full flex-1 flex items-end justify-center">
                    <div
                      style={{ height: `${Math.max(pct, 8)}%` }}
                      className="w-4/5 rounded bg-indigo-500/80 hover:bg-indigo-400 transition-all cursor-pointer shadow-sm"
                    />
                  </div>
                  <span className={`text-[8px] mt-1.5 font-medium ${isDarkMode ? "text-slate-500" : "text-slate-400"}`}>
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Monthly Earnings Stack Chart style */}
        <div className={`p-3 rounded-2xl border ${isDarkMode ? "bg-slate-900/60 border-slate-800" : "bg-white border-slate-200"} shadow-sm`}>
          <div className="flex justify-between items-center mb-2">
            <h4 className={`text-[11px] font-bold uppercase tracking-wider ${isDarkMode ? "text-slate-400" : "text-slate-500"}`}>Monthly Earnings Trend</h4>
            <span className="text-[10px] font-mono text-teal-500 font-bold">₹{monthlyData.reduce((s, x) => s + x.value, 0).toLocaleString()}</span>
          </div>
          <div className="h-28 flex items-end justify-between gap-1 pt-3">
            {monthlyData.map((item, idx) => {
              const pct = (item.value / maxMonthly) * 100;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center h-full relative group">
                  <div className="text-[9px] text-teal-500 font-mono font-bold opacity-0 group-hover:opacity-100 absolute -top-3 bg-slate-950 px-1 py-0.5 rounded transition-opacity">
                    ₹{item.value}
                  </div>
                  <div className="w-full flex-1 flex items-end justify-center">
                    <div
                      style={{ height: `${Math.max(pct, 8)}%` }}
                      className="w-4/5 rounded bg-teal-500/80 hover:bg-teal-400 transition-all cursor-pointer shadow-sm"
                    />
                  </div>
                  <span className={`text-[8px] mt-1.5 font-medium ${isDarkMode ? "text-slate-500" : "text-slate-400"}`}>
                    {item.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
