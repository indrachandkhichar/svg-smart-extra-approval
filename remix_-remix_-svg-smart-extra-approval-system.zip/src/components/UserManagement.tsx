import React, { useState } from "react";
import { Employee } from "../types";
import { UserPlus, Edit3, Trash2, Key, ToggleLeft, ToggleRight, CheckSquare, ShieldCheck, X } from "lucide-react";

interface UserManagementProps {
  employees: Employee[];
  onAddEmployee: (emp: Employee) => void;
  onUpdateEmployee: (emp: Employee) => void;
  onDeleteEmployee: (empId: string) => void;
  isDarkMode: boolean;
}

export const UserManagement: React.FC<UserManagementProps> = ({
  employees,
  onAddEmployee,
  onUpdateEmployee,
  onDeleteEmployee,
  isDarkMode
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  
  // Form states
  const [empId, setEmpId] = useState("");
  const [passwordPin, setPasswordPin] = useState("");
  const [branchName, setBranchName] = useState("Chennai");
  const [role, setRole] = useState<"Admin" | "Branch User">("Branch User");
  const [permissions, setPermissions] = useState<string[]>(["Export Reports"]);
  const [status, setStatus] = useState<"Active" | "Inactive">("Active");

  const [selectedEmp, setSelectedEmp] = useState<Employee | null>(null);

  const availablePermissions = [
    "Import Excel",
    "Export Reports",
    "Approve Requests",
    "Create Users",
    "Modify Ledger"
  ];

  const handleTogglePermission = (p: string) => {
    if (permissions.includes(p)) {
      setPermissions(permissions.filter((x) => x !== p));
    } else {
      setPermissions([...permissions, p]);
    }
  };

  const resetForm = () => {
    setEmpId("");
    setPasswordPin("");
    setBranchName("Chennai");
    setRole("Branch User");
    setPermissions(["Export Reports"]);
    setStatus("Active");
    setSelectedEmp(null);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!empId || !passwordPin) {
      alert("Please specify both Employee ID and password pin.");
      return;
    }
    if (empId.includes("@") || empId.includes(" ")) {
      alert("Employee ID must be alphanumeric (e.g. CH01, SI02, RT01) without spaces or @ symbols.");
      return;
    }

    if (employees.some((x) => x.employeeId.toLowerCase() === empId.toLowerCase())) {
      alert(`User with Employee ID "${empId}" already exists.`);
      return;
    }

    const newEmp: Employee = {
      employeeId: empId.toUpperCase(),
      passwordPin,
      role,
      branchName,
      permissions,
      status: "Active"
    };

    onAddEmployee(newEmp);
    setShowAddModal(false);
    resetForm();
  };

  const handleEditClick = (emp: Employee) => {
    setSelectedEmp(emp);
    setEmpId(emp.employeeId);
    setPasswordPin(emp.passwordPin);
    setBranchName(emp.branchName || "Chennai");
    setRole(emp.role);
    setPermissions(emp.permissions || []);
    setStatus(emp.status || "Active");
    setShowEditModal(true);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordPin) {
      alert("Please provide a password pin.");
      return;
    }

    if (!selectedEmp) return;

    const updatedEmp: Employee = {
      ...selectedEmp,
      passwordPin,
      role,
      branchName,
      permissions,
      status
    };

    onUpdateEmployee(updatedEmp);
    setShowEditModal(false);
    resetForm();
  };

  const handleToggleActiveState = (emp: Employee) => {
    const updated: Employee = {
      ...emp,
      status: emp.status === "Active" ? "Inactive" : "Active"
    };
    onUpdateEmployee(updated);
  };

  return (
    <div className="space-y-4">
      {/* Header Panel with Create Button */}
      <div className="flex justify-between items-center border-b border-slate-800/20 pb-3">
        <div>
          <h3 className={`text-xs font-bold uppercase tracking-wider ${isDarkMode ? "text-slate-200" : "text-slate-800"}`}>
            System Personnel Directory ({employees.length})
          </h3>
          <p className="text-[10px] text-slate-500">Create, edit, reset PIN credentials and toggle status rules.</p>
        </div>
        <button
          onClick={() => {
            resetForm();
            setShowAddModal(true);
          }}
          className="bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg flex items-center gap-1 cursor-pointer transition-all shadow"
        >
          <UserPlus className="h-3.5 w-3.5" /> Add User
        </button>
      </div>

      {/* User Ledger Table Grid */}
      <div className={`border rounded-2xl overflow-hidden ${isDarkMode ? "bg-slate-950 border-slate-800" : "bg-white border-slate-200"} shadow-sm`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[11px]">
            <thead className={`font-bold uppercase text-[10px] ${isDarkMode ? "bg-slate-900/80 text-slate-400" : "bg-slate-50 text-slate-500"}`}>
              <tr>
                <th className="p-3">Employee ID</th>
                <th className="p-3">Designation / Role</th>
                <th className="p-3">Assigned Station</th>
                <th className="p-3">Active Permissions</th>
                <th className="p-3">Account Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className={`divide-y ${isDarkMode ? "divide-slate-800" : "divide-slate-200"}`}>
              {employees.map((emp) => (
                <tr key={emp.employeeId} className={emp.status === "Inactive" ? "opacity-60 bg-red-950/5" : ""}>
                  <td className="p-3 font-mono font-bold text-white">
                    <span className={`px-2 py-0.5 rounded ${isDarkMode ? "bg-slate-900" : "bg-slate-100 text-slate-800"}`}>
                      {emp.employeeId}
                    </span>
                  </td>
                  <td className="p-3 font-semibold">
                    <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                      emp.role === "Admin" ? "bg-orange-500/10 text-orange-500" : "bg-blue-500/10 text-blue-500"
                    }`}>
                      {emp.role}
                    </span>
                  </td>
                  <td className={`p-3 font-medium ${isDarkMode ? "text-slate-300" : "text-slate-600"}`}>
                    {emp.branchName || "All Stations"}
                  </td>
                  <td className="p-3">
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {(emp.permissions || []).map((p) => (
                        <span key={p} className="bg-slate-800/80 text-slate-300 border border-slate-700/50 text-[8px] font-semibold px-1.5 py-0.2 rounded">
                          {p}
                        </span>
                      ))}
                      {(emp.permissions || []).length === 0 && (
                        <span className="text-[10px] text-slate-500 italic">None</span>
                      )}
                    </div>
                  </td>
                  <td className="p-3">
                    <button
                      onClick={() => handleToggleActiveState(emp)}
                      className={`flex items-center gap-1 font-bold text-[10px] hover:underline cursor-pointer ${
                        emp.status === "Inactive" ? "text-red-500" : "text-green-500"
                      }`}
                    >
                      {emp.status === "Inactive" ? (
                        <>
                          <ToggleLeft className="h-4 w-4" /> Disabled
                        </>
                      ) : (
                        <>
                          <ToggleRight className="h-4 w-4" /> Active
                        </>
                      )}
                    </button>
                  </td>
                  <td className="p-3 text-right">
                    <div className="flex justify-end gap-1.5">
                      <button
                        onClick={() => handleEditClick(emp)}
                        className={`p-1.5 rounded-md hover:bg-slate-800 transition-all cursor-pointer ${
                          isDarkMode ? "text-slate-400 hover:text-white" : "text-slate-500 hover:text-slate-800"
                        }`}
                        title="Edit PIN & Permissions"
                      >
                        <Edit3 className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (emp.employeeId === "CH01") {
                            alert("Protected account. Standard master administrator account cannot be expunged.");
                            return;
                          }
                          if (confirm(`Expunge employee profile "${emp.employeeId}" permanently from this Room vault?`)) {
                            onDeleteEmployee(emp.employeeId);
                          }
                        }}
                        className="p-1.5 rounded-md hover:bg-slate-800 text-red-500 hover:text-red-400 transition-all cursor-pointer"
                        title="Delete Employee"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL: ADD USER */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 z-[60]">
          <div className={`w-full max-w-md rounded-2xl p-5 border text-xs ${
            isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
          }`}>
            <div className="flex justify-between items-center border-b border-slate-800/10 pb-3 mb-4">
              <h3 className="font-bold text-sm flex items-center gap-1">
                <UserPlus className="h-4 w-4 text-blue-500" /> Create Logistics Profile
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Employee ID (Login ID)</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. SI05, CH04, RT12"
                  value={empId}
                  onChange={(e) => setEmpId(e.target.value.trim())}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Secret Access PIN (Password)</label>
                <input
                  type="password"
                  required
                  placeholder="Secret numeric PIN e.g. 5678"
                  value={passwordPin}
                  onChange={(e) => setPasswordPin(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Access Role</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as "Admin" | "Branch User")}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-sm text-white focus:outline-none"
                  >
                    <option value="Branch User">Branch User</option>
                    <option value="Admin">Master Admin</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Assigned Branch</label>
                  <select
                    value={branchName}
                    onChange={(e) => setBranchName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-sm text-white focus:outline-none"
                  >
                    <option value="Chennai">Chennai (CH)</option>
                    <option value="Siliguri">Siliguri (SI)</option>
                    <option value="Rohtak">Rohtak (RT)</option>
                    <option value="Kolkata">Kolkata (KO)</option>
                    <option value="Mumbai">Mumbai (MU)</option>
                    <option value="Delhi">Delhi (DL)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Assigned Security Permissions</label>
                <div className="grid grid-cols-2 gap-1.5 mt-1.5">
                  {availablePermissions.map((p) => {
                    const isChecked = permissions.includes(p);
                    return (
                      <button
                        type="button"
                        key={p}
                        onClick={() => handleTogglePermission(p)}
                        className={`p-2 rounded-xl text-left font-semibold flex items-center gap-1.5 border transition-all ${
                          isChecked
                            ? "bg-blue-600/10 border-blue-500 text-blue-400"
                            : "bg-slate-950 border-slate-850 text-slate-500"
                        }`}
                      >
                        <CheckSquare className={`h-3 w-3 ${isChecked ? "text-blue-500" : "text-slate-600"}`} />
                        <span>{p}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex gap-2 pt-3 border-t border-slate-850">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 rounded-xl cursor-pointer"
                >
                  Confirm Insert
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDIT USER */}
      {showEditModal && selectedEmp && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 z-[60]">
          <div className={`w-full max-w-md rounded-2xl p-5 border text-xs ${
            isDarkMode ? "bg-slate-900 border-slate-800 text-white" : "bg-white border-slate-200 text-slate-900"
          }`}>
            <div className="flex justify-between items-center border-b border-slate-800/10 pb-3 mb-4">
              <h3 className="font-bold text-sm flex items-center gap-1">
                <Edit3 className="h-4 w-4 text-orange-500" /> Edit Profile: {selectedEmp.employeeId}
              </h3>
              <button onClick={() => setShowEditModal(false)} className="text-slate-400 hover:text-white">
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-3">
              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Access PIN (Password)</label>
                <input
                  type="text"
                  required
                  placeholder="Reset pin passcode..."
                  value={passwordPin}
                  onChange={(e) => setPasswordPin(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-sm text-white focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Role Type</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as "Admin" | "Branch User")}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-sm text-white focus:outline-none"
                  >
                    <option value="Branch User">Branch User</option>
                    <option value="Admin">Master Admin</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Branch Station</label>
                  <select
                    value={branchName}
                    onChange={(e) => setBranchName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 text-sm text-white focus:outline-none"
                  >
                    <option value="Chennai">Chennai (CH)</option>
                    <option value="Siliguri">Siliguri (SI)</option>
                    <option value="Rohtak">Rohtak (RT)</option>
                    <option value="Kolkata">Kolkata (KO)</option>
                    <option value="Mumbai">Mumbai (MU)</option>
                    <option value="Delhi">Delhi (DL)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1">Permissions Scope</label>
                <div className="grid grid-cols-2 gap-1.5 mt-1.5">
                  {availablePermissions.map((p) => {
                    const isChecked = permissions.includes(p);
                    return (
                      <button
                        type="button"
                        key={p}
                        onClick={() => handleTogglePermission(p)}
                        className={`p-2 rounded-xl text-left font-semibold flex items-center gap-1.5 border transition-all ${
                          isChecked
                            ? "bg-blue-600/10 border-blue-500 text-blue-400"
                            : "bg-slate-950 border-slate-850 text-slate-500"
                        }`}
                      >
                        <CheckSquare className={`h-3 w-3 ${isChecked ? "text-blue-500" : "text-slate-600"}`} />
                        <span>{p}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-850">
                <div>
                  <span className="font-bold text-white block">Account Locked / Disabled</span>
                  <p className="text-[10px] text-slate-500">Temporarily prevent this personnel from authenticating.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setStatus(status === "Active" ? "Inactive" : "Active")}
                  className={`text-2xl cursor-pointer ${status === "Inactive" ? "text-red-500" : "text-slate-500"}`}
                >
                  {status === "Inactive" ? <ToggleLeft className="h-8 w-8 text-red-500" /> : <ToggleRight className="h-8 w-8 text-green-500" />}
                </button>
              </div>

              <div className="flex gap-2 pt-3 border-t border-slate-850">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-2 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 rounded-xl cursor-pointer"
                >
                  Save Modifications
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
