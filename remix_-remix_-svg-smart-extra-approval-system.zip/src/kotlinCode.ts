export interface AndroidCodeFile {
  path: string;
  language: string;
  content: string;
  description: string;
}

export const ANDROID_PROJECT_FILES: AndroidCodeFile[] = [
  {
    path: "app/build.gradle.kts",
    language: "kotlin",
    description: "Android Gradle configuration with Room, Hilt, Navigation, and Apache POI (for Excel processing) dependencies.",
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    id("kotlin-kapt")
    id("dagger.hilt.android.plugin")
}

android {
    namespace = "com.svg.smartapproval"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.svg.smartapproval"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/DEPENDENCIES"
        }
    }
}

dependencies {
    // Jetpack Compose
    implementation(platform("androidx.compose:compose-bom:2024.01.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.navigation:navigation-compose:2.7.6")

    // Room Database (with SQLCipher for local encryption)
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    kapt("androidx.room:room-compiler:$roomVersion")
    implementation("net.zetetic:android-database-sqlcipher:4.5.4") // SQLite Encryption

    // Hilt Dependency Injection
    implementation("com.google.dagger:hilt-android:2.50")
    kapt("com.google.dagger:hilt-compiler:2.50")
    implementation("androidx.hilt:hilt-navigation-compose:1.1.0")

    // Coroutines & Lifecycle
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.7.0")

    // Excel & PDF Generation (POI & iText)
    implementation("org.apache.poi:poi-ooxml:5.2.5")
    implementation("com.itextpdf:itextg:5.5.10") // Light Android port of iText PDF

    // Local Preferences Datastore
    implementation("androidx.datastore:datastore-preferences:1.0.0")
}`
  },
  {
    path: "app/src/main/AndroidManifest.xml",
    language: "xml",
    description: "Standard Android Manifest declaring hardware permissions for local file read/write, local hotspot configuration, and launcher details.",
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <!-- Permissions for local data importing/exporting (Android 10 and below & Legacy) -->
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" tools:ignore="ScopedStorage" />
    
    <!-- Local Hotspot Offline Sync and Wi-Fi pairing -->
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
    <uses-permission android:name="android.permission.NEARBY_WIFI_DEVICES" android:usesPermissionFlags="neverForLocation" />

    <application
        android:name=".SmartApprovalApp"
        android:allowBackup="false"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.SmartApproval"
        tools:targetApi="34">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize"
            android:theme="@style/Theme.SmartApproval">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`
  },
  {
    path: "app/src/main/java/com/svg/smartapproval/data/Entities.kt",
    language: "kotlin",
    description: "Database Tables. Optimization indices are defined on AWB Number, Branch Name, and Customer Name to support instant search of 50,000+ records.",
    content: `package com.svg.smartapproval.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "employees",
    indices = [Index(value = ["employeeId"], unique = true)]
)
data class EmployeeEntity(
    @PrimaryKey val employeeId: string, // e.g. CH01, SI02
    val passwordPin: String, // 4-digit PIN e.g. 1234
    val branchName: String,
    val status: String, // "Active" | "Inactive"
    val role: String // "Admin" | "Branch User"
)

@Entity(
    tableName = "awb_bookings",
    indices = [
        Index(value = ["awbNumber"], unique = true),
        Index(value = ["branch"]),
        Index(value = ["customerName"]),
        Index(value = ["mobile"])
    ]
)
data class AwbEntity(
    @PrimaryKey val awbNumber: String,
    val bookingDate: String, // YYYY-MM-DD
    val customerName: String,
    val address: String,
    val mobile: String,
    val branch: String,
    val quantity: Int,
    val weight: Double,
    val originalAmount: Double,
    val additionalApprovedAmount: Double,
    val totalAmount: Double,
    val approvalStatus: String, // "Pending", "Approved", "Rejected", "None"
    val remark: String,
    val uploadDate: String
)

@Entity(
    tableName = "approvals",
    indices = [
        Index(value = ["awbNumber"]),
        Index(value = ["employeeId"])
    ]
)
data class ApprovalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val awbNumber: String,
    val requestedAmount: Double,
    val reason: String,
    val remarks: String,
    val status: String, // "Pending", "Approved", "Rejected"
    val approvedAmount: Double,
    val adminRemark: String,
    val approvedDate: String,
    val employeeId: String
)`
  },
  {
    path: "app/src/main/java/com/svg/smartapproval/data/AppDatabase.kt",
    language: "kotlin",
    description: "Encrypted SQLite Room Database implementation utilizing SQLCipher and a secure database password.",
    content: `package com.svg.smartapproval.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

@Database(
    entities = [EmployeeEntity::class, AwbEntity::class, ApprovalEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun employeeDao(): EmployeeDao
    abstract fun awbDao(): AwbDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                // Highly secure password derived on device (normally fetched via Keystore)
                val passphrase = SQLiteDatabase.getBytes("SecureOfflinePINPassphrase1024".toCharArray())
                val factory = SupportFactory(passphrase)

                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "svg_offline_db"
                )
                .openHelperFactory(factory) // Encrypts database with AES-256 using SQLCipher
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}`
  },
  {
    path: "app/src/main/java/com/svg/smartapproval/data/Daos.kt",
    language: "kotlin",
    description: "Room DAOs optimized for lightning-fast queries, search index matchers, and aggregate queries.",
    content: `package com.svg.smartapproval.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface EmployeeDao {
    @Query("SELECT * FROM employees WHERE employeeId = :id LIMIT 1")
    suspend fun getEmployeeById(id: String): EmployeeEntity?

    @Query("SELECT * FROM employees")
    fun getAllEmployees(): Flow<List<EmployeeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployee(employee: EmployeeEntity)

    @Query("DELETE FROM employees WHERE employeeId = :id")
    suspend fun deleteEmployee(id: String)
}

@Dao
interface AwbDao {
    // Quick Dashboard Count Queries
    @Query("SELECT COUNT(*) FROM awb_bookings")
    suspend fun getAwbCount(): Int

    @Query("SELECT COUNT(*) FROM awb_bookings WHERE branch = :branch")
    fun getBranchAwbCountFlow(branch: String): Flow<Int>

    // 50,000+ Record Lightning Fast Cursor Search
    @Query("""
        SELECT * FROM awb_bookings 
        WHERE (:branch = 'Admin' OR branch = :branch)
        AND (awbNumber LIKE '%' || :query || '%' 
             OR customerName LIKE '%' || :query || '%' 
             OR mobile LIKE '%' || :query || '%')
        AND (:status = 'All' OR approvalStatus = :status)
        ORDER BY bookingDate DESC
    """)
    fun searchAwbs(branch: String, query: String, status: String): Flow<List<AwbEntity>>

    @Query("SELECT * FROM awb_bookings WHERE awbNumber = :awb LIMIT 1")
    suspend fun getAwbDetails(awb: String): AwbEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAwbs(awbs: List<AwbEntity>)

    @Query("UPDATE awb_bookings SET additionalApprovedAmount = :addAmt, totalAmount = originalAmount + :addAmt, approvalStatus = :status, remark = :remark WHERE awbNumber = :awb")
    suspend fun updateAwbStatus(awb: String, addAmt: Double, status: String, remark: String)

    // Approvals Management
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApprovalRequest(approval: ApprovalEntity)

    @Query("SELECT * FROM approvals WHERE status = :status ORDER BY id DESC")
    fun getApprovalsByStatus(status: String): Flow<List<ApprovalEntity>>

    @Query("SELECT * FROM approvals WHERE employeeId = :empId ORDER BY id DESC")
    fun getApprovalsByEmployee(empId: String): Flow<List<ApprovalEntity>>

    @Transaction
    suspend fun approveRequestTransaction(awb: String, approvedAmount: Double, adminRemark: String, approvedDate: String) {
        updateAwbStatus(awb, approvedAmount, "Approved", adminRemark)
        updateApprovalState(awb, "Approved", approvedAmount, adminRemark, approvedDate)
    }

    @Transaction
    suspend fun rejectRequestTransaction(awb: String, adminRemark: String, approvedDate: String) {
        updateAwbStatus(awb, 0.0, "Rejected", adminRemark)
        updateApprovalState(awb, "Rejected", 0.0, adminRemark, approvedDate)
    }

    @Query("UPDATE approvals SET status = :status, approvedAmount = :appAmt, adminRemark = :remark, approvedDate = :date WHERE awbNumber = :awb AND status = 'Pending'")
    suspend fun updateApprovalState(awb: String, status: String, appAmt: Double, remark: String, date: String)

    // Reports Aggregations
    @Query("SELECT SUM(originalAmount) FROM awb_bookings WHERE (:branch = 'Admin' OR branch = :branch)")
    suspend fun getSumOriginal(branch: String): Double?

    @Query("SELECT SUM(additionalApprovedAmount) FROM awb_bookings WHERE (:branch = 'Admin' OR branch = :branch)")
    suspend fun getSumApproved(branch: String): Double?

    @Query("SELECT SUM(totalAmount) FROM awb_bookings WHERE (:branch = 'Admin' OR branch = :branch)")
    suspend fun getSumTotal(branch: String): Double?
}`
  },
  {
    path: "app/src/main/java/com/svg/smartapproval/repository/BookingRepository.kt",
    language: "kotlin",
    description: "Repository layer implementing single source of truth and local database flow handlers for Room.",
    content: `package com.svg.smartapproval.repository

import com.svg.smartapproval.data.AwbDao
import com.svg.smartapproval.data.AwbEntity
import com.svg.smartapproval.data.EmployeeDao
import com.svg.smartapproval.data.EmployeeEntity
import com.svg.smartapproval.data.ApprovalEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BookingRepository @Inject constructor(
    private val employeeDao: EmployeeDao,
    private val awbDao: AwbDao
) {
    // Employee methods
    suspend fun getEmployee(id: String): EmployeeEntity? = withContext(Dispatchers.IO) {
        employeeDao.getEmployeeById(id)
    }

    fun getAllEmployees(): Flow<List<EmployeeEntity>> = employeeDao.getAllEmployees()

    suspend fun addEmployee(emp: EmployeeEntity) = withContext(Dispatchers.IO) {
        employeeDao.insertEmployee(emp)
    }

    suspend fun deleteEmployee(id: String) = withContext(Dispatchers.IO) {
        employeeDao.deleteEmployee(id)
    }

    // AWB methods
    fun searchAwbs(branch: String, query: String, status: String): Flow<List<AwbEntity>> {
        return awbDao.searchAwbs(branch, query, status)
    }

    suspend fun getAwbDetails(awbNumber: String): AwbEntity? = withContext(Dispatchers.IO) {
        awbDao.getAwbDetails(awbNumber)
    }

    suspend fun insertBookingBatch(awbs: List<AwbEntity>) = withContext(Dispatchers.IO) {
        awbDao.insertAwbs(awbs)
    }

    // Extra Approval operations
    suspend fun requestExtraApproval(req: ApprovalEntity) = withContext(Dispatchers.IO) {
        awbDao.insertApprovalRequest(req)
        awbDao.updateAwbStatus(req.awbNumber, 0.0, "Pending", "Approval Requested: " + req.reason)
    }

    fun getPendingRequests(): Flow<List<ApprovalEntity>> = awbDao.getApprovalsByStatus("Pending")
    
    fun getCompletedRequests(status: String): Flow<List<ApprovalEntity>> = awbDao.getApprovalsByStatus(status)

    fun getBranchRequests(empId: String): Flow<List<ApprovalEntity>> = awbDao.getApprovalsByEmployee(empId)

    suspend fun approveRequest(awb: String, approvedAmount: Double, remark: String, date: String) = withContext(Dispatchers.IO) {
        awbDao.approveRequestTransaction(awb, approvedAmount, remark, date)
    }

    suspend fun rejectRequest(awb: String, remark: String, date: String) = withContext(Dispatchers.IO) {
        awbDao.rejectRequestTransaction(awb, remark, date)
    }

    // Reports aggregate fetchers
    suspend fun getBranchStats(branch: String) = withContext(Dispatchers.IO) {
        val original = awbDao.getSumOriginal(branch) ?: 0.0
        val approved = awbDao.getSumApproved(branch) ?: 0.0
        val total = awbDao.getSumTotal(branch) ?: 0.0
        Triple(original, approved, total)
    }
}`
  },
  {
    path: "app/src/main/java/com/svg/smartapproval/ui/ViewModels.kt",
    language: "kotlin",
    description: "Jetpack Compose MVVM ViewModels linking Compose state UI flow directly with the secure Room DB repository.",
    content: `package com.svg.smartapproval.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.svg.smartapproval.data.AwbEntity
import com.svg.smartapproval.data.EmployeeEntity
import com.svg.smartapproval.data.ApprovalEntity
import com.svg.smartapproval.repository.BookingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val repository: BookingRepository
) : ViewModel() {

    private val _currentUser = MutableStateFlow<EmployeeEntity?>(null)
    val currentUser: StateFlow<EmployeeEntity?> = _currentUser.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _statusFilter = MutableStateFlow("All")
    val statusFilter: StateFlow<String> = _statusFilter.asStateFlow()

    // High performance reactive StateFlow binding search queries & filters directly to SQLite indexes
    val searchResults: StateFlow<List<AwbEntity>> = combine(
        _currentUser,
        _searchQuery,
        _statusFilter
    ) { user, query, filter ->
        val branchScope = if (user?.role == "Admin") "Admin" else user?.branchName ?: ""
        branchScope to (query to filter)
    }.flatMapLatest { (branch, search) ->
        repository.searchAwbs(branch, search.first, search.second)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _pendingRequests = MutableStateFlow<List<ApprovalEntity>>(emptyList())
    val pendingRequests: StateFlow<List<ApprovalEntity>> = _pendingRequests.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getPendingRequests().collect {
                _pendingRequests.value = it
            }
        }
    }

    fun login(employeeId: String, pin: String, onSuccess: (EmployeeEntity) -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            if (employeeId == "admin" && pin == "9999") {
                val admin = EmployeeEntity("admin", "9999", "Admin", "Active", "Admin")
                _currentUser.value = admin
                onSuccess(admin)
                return@launch
            }
            val emp = repository.getEmployee(employeeId)
            if (emp != null && emp.passwordPin == pin && emp.status == "Active") {
                _currentUser.value = emp
                onSuccess(emp)
            } else {
                onError("Invalid Employee ID or security PIN!")
            }
        }
    }

    fun setQuery(q: String) { _searchQuery.value = q }
    fun setFilter(f: String) { _statusFilter.value = f }

    fun requestExtraApproval(awbNumber: String, amount: Double, reason: String, remarks: String) {
        viewModelScope.launch {
            val user = _currentUser.value ?: return@launch
            val req = ApprovalEntity(
                awbNumber = awbNumber,
                requestedAmount = amount,
                reason = reason,
                remarks = remarks,
                status = "Pending",
                approvedAmount = 0.0,
                adminRemark = "",
                approvedDate = "",
                employeeId = user.employeeId
            )
            repository.requestExtraApproval(req)
        }
    }

    fun handleApproval(awbNumber: String, approvedAmount: Double, remark: String, approved: Boolean) {
        viewModelScope.launch {
            val dateStr = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            if (approved) {
                repository.approveRequest(awbNumber, approvedAmount, remark, dateStr)
            } else {
                repository.rejectRequest(awbNumber, remark, dateStr)
            }
        }
    }

    fun logout() {
        _currentUser.value = null
    }
}`
  },
  {
    path: "app/src/main/java/com/svg/smartapproval/ui/ComposeScreens.kt",
    language: "kotlin",
    description: "Jetpack Compose UI. Highlights beautiful rounded cards, Material 3 layouts, local CSV processor interfaces, and branch restricted lists.",
    content: `package com.svg.smartapproval.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.svg.smartapproval.data.AwbEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit,
    viewModel: MainViewModel
) {
    var empId by remember { mutableStateOf("") }
    var pinCode by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F172A), Color(0xFF1E3A8A))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Lock Logo",
                    tint = Color(0xFF2563EB),
                    modifier = Modifier.size(64.dp)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "SVG Smart Approval",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Text(
                    text = "Offline Local Logistics Database",
                    fontSize = 12.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = empId,
                    onValueChange = { empId = it },
                    label = { Text("Employee ID") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = pinCode,
                    onValueChange = { pinCode = it },
                    label = { Text("4-Digit Security PIN") },
                    leadingIcon = { Icon(Icons.Default.CheckCircle, contentDescription = null) },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorMessage!!, color = Color.Red, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        viewModel.login(empId, pinCode, {
                            onLoginSuccess()
                        }, {
                            errorMessage = it
                        })
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF))
                ) {
                    Text("Secure Offline Login", color = Color.White)
                }
            }
        }
    }
}

@Composable
fun BranchDashboardScreen(
    viewModel: MainViewModel,
    onAwbClicked: (AwbEntity) -> Unit
) {
    val userState by viewModel.currentUser.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val filterState by viewModel.statusFilter.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
    ) {
        // Gradient Premium Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Color(0xFF1E40AF), Color(0xFFF97316))
                    )
                )
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "Branch Panel: \${userState?.branchName ?: "Offline"}",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "ID: \${userState?.employeeId ?: ""} | Offline Secure Link Active",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }

        // Stats Cards Scrollable row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Card(
                modifier = Modifier.weight(1f).padding(4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Bookings", fontSize = 11.sp, color = Color.DarkGray)
                    Text("\${searchResults.size}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF))
                }
            }
            Card(
                modifier = Modifier.weight(1f).padding(4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Pending", fontSize = 11.sp, color = Color.DarkGray)
                    Text(
                        "\${searchResults.count { it.approvalStatus == "Pending" }}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD97706)
                    )
                }
            }
        }

        // Instant filter search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setQuery(it) },
            placeholder = { Text("Search AWB, customer, mobile...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )

        // ListView of AWB bookings assigned strictly to this branch
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(searchResults) { awb ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onAwbClicked(awb) },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("AWB: \${awb.awbNumber}", fontWeight = FontWeight.Bold)
                            Text("Customer: \${awb.customerName}", fontSize = 13.sp, color = Color.Gray)
                            Text("Original: ₹\${awb.originalAmount}", fontSize = 12.sp, color = Color.DarkGray)
                        }
                        
                        // Status Badge
                        val badgeColor = when (awb.approvalStatus) {
                            "Approved" -> Color(0xFF16A34A)
                            "Rejected" -> Color(0xFFDC2626)
                            "Pending" -> Color(0xFFD97706)
                            else -> Color.Gray
                        }
                        Card(
                            colors = CardDefaults.cardColors(containerColor = badgeColor.copy(alpha = 0.15f))
                        ) {
                            Text(
                                text = awb.approvalStatus,
                                color = badgeColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}`
  }
];
